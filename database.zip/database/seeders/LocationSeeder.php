<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Location;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class LocationSeeder extends Seeder
{
    use WithoutModelEvents;

    public function run(): void
    {
        // Get categories
        $iBadah = Category::where('name', 'Tempat Ibadah')->first();
        $restoran = Category::where('name', 'Restoran')->first();
        $rumahSakit = Category::where('name', 'Rumah Sakit')->first();
        $taman = Category::where('name', 'Taman')->first();
        $perpustakaan = Category::where('name', 'Perpustakaan')->first();

        // Tempat Ibadah
        Location::create([
            'category_id' => $iBadah->id,
            'name' => 'Masjid Agung Palembang',
            'slug' => 'masjid-agung-palembang',
            'description' => 'Masjid bersejarah yang indah dengan arsitektur tradisional Palembang. Dilengkapi dengan fasilitas lengkap untuk ibadah.',
            'accessibility_info' => "Tersedia jalur khusus kursi roda dari pintu masuk\nWisuda dan kamar mandi khusus aksesibel\nArea parkir dekat dengan entrance\nTersedia tempat duduk khusus untuk yang kesulitan berdiri\nMem memiliki pegangan tangan di area wudhu",
            'notes' => 'Buka untuk umum pada waktu shalat berjamaah. Tersedia program pengajian setiap hari Jumat.',
            'google_maps_url' => 'https://maps.google.com/maps?q=masjid+agung+palembang',
            'is_published' => true,
        ]);

        Location::create([
            'category_id' => $iBadah->id,
            'name' => 'Gereja Katedral Palembang',
            'slug' => 'gereja-katedral-palembang',
            'description' => 'Gereja bersejarah dengan arsitektur indah di pusat Kota Palembang.',
            'accessibility_info' => "Tersedia lift untuk mencapai lantai atas\nToilet khusus aksesibel tersedia\nJalur masuk yang landau untuk kursi roda\nArea parkir khusus untuk penyandang disabilitas",
            'notes' => 'Pelayanan ibadah setiap hari Minggu pukul 07:00 dan 10:00.',
            'google_maps_url' => 'https://maps.google.com/maps?q=gereja+katedral+palembang',
            'is_published' => true,
        ]);

        // Restoran
        Location::create([
            'category_id' => $restoran->id,
            'name' => 'Pempek Betutu',
            'slug' => 'pempek-betutu',
            'description' => 'Restoran pempek tradisional Palembang dengan cita rasa autentik dan layanan ramah.',
            'accessibility_info' => "Meja kursi roda tersedia di area restoran\nWisuda aksesibel dekat dengan area makan\nRuang yang luas untuk memarkir kursi roda\nStaf terlatih untuk membantu penyandang disabilitas",
            'notes' => 'Buka setiap hari dari jam 10:00-22:00. Tersedia layanan delivery.',
            'google_maps_url' => 'https://maps.google.com/maps?q=pempek+betutu+palembang',
            'is_published' => true,
        ]);

        Location::create([
            'category_id' => $restoran->id,
            'name' => 'Musi Cafe & Resto',
            'slug' => 'musi-cafe-resto',
            'description' => 'Kafe dengan pemandangan Sungai Musi yang indah, menyajikan masakan nusantara dan internasional.',
            'accessibility_info' => "Akses masuk tanpa tangga\nWisuda di dekat area dining\nArea parkir yang cukup luas\nMeja dengan ruang khusus untuk kursi roda",
            'notes' => 'Lokasi strategis di tepi Sungai Musi. Cocok untuk acara perusahaan.',
            'google_maps_url' => 'https://maps.google.com/maps?q=musi+cafe+palembang',
            'is_published' => true,
        ]);

        // Rumah Sakit
        Location::create([
            'category_id' => $rumahSakit->id,
            'name' => 'Rumah Sakit Umum Daerah Palembang',
            'slug' => 'rsud-palembang',
            'description' => 'Rumah sakit utama di Kota Palembang dengan pelayanan emergency 24 jam dan berbagai spesialisasi.',
            'accessibility_info' => "Tersedia lift di semua lantai\nToilet aksesibel di setiap lantai\nParkir khusus untuk penyandang disabilitas\nAkses masuk dengan jalur yang rata\nStaf medis terlatih dalam menangani pasien disabilitas",
            'notes' => 'Setiap pasien mendapat kartu tanda masuk. Rujukan dapat dilakukan dari fasilitas kesehatan lain.',
            'google_maps_url' => 'https://maps.google.com/maps?q=rsud+palembang',
            'is_published' => true,
        ]);

        Location::create([
            'category_id' => $rumahSakit->id,
            'name' => 'Rumah Sakit Swasta Musi',
            'slug' => 'rs-musi-palembang',
            'description' => 'Rumah sakit modern dengan teknologi medis terkini dan pelayanan prima.',
            'accessibility_info' => "Fasilitas lengkap untuk mobilitas\nWisuda modern dan luas\nArea tunggu khusus\nLayanan porter untuk membantu mobilitas pasien",
            'notes' => 'Memiliki unit rawat inap kelas 1, 2, dan 3. Tersedia akomodasi keluarga.',
            'google_maps_url' => 'https://maps.google.com/maps?q=rs+musi+palembang',
            'is_published' => true,
        ]);

        // Taman
        Location::create([
            'category_id' => $taman->id,
            'name' => 'Taman Segitiga',
            'slug' => 'taman-segitiga',
            'description' => 'Taman tua yang indah di pusat Kota Palembang, tempat favorit bermain keluarga.',
            'accessibility_info' => "Jalur setapak yang rata dan lebar\nBanches untuk istirahat tersebar di area taman\nToilet umum tersedia\nAkses masuk dari berbagai pintu\nArea parkir cukup luas",
            'notes' => 'Terbuka setiap hari dari jam 06:00-22:00. Aman untuk keluarga dan cocok untuk jogging.',
            'google_maps_url' => 'https://maps.google.com/maps?q=taman+segitiga+palembang',
            'is_published' => true,
        ]);

        // Perpustakaan
        Location::create([
            'category_id' => $perpustakaan->id,
            'name' => 'Perpustakaan Daerah Sumatera Selatan',
            'slug' => 'perpustakaan-daerah-sumsel',
            'description' => 'Perpustakaan daerah dengan koleksi buku lengkap dan fasilitas modern untuk penelitian.',
            'accessibility_info' => "Akses masuk datar tanpa tangga\nLift tersedia untuk lantai atas\nArea khusus baca untuk kursi roda\nWisuda yang luas dan bersih\nMeja komputer dengan akses aksesibel",
            'notes' => 'Gratis untuk umum. Buka Senin-Jumat 08:00-17:00, Sabtu 08:00-14:00.',
            'google_maps_url' => 'https://maps.google.com/maps?q=perpustakaan+daerah+palembang',
            'is_published' => true,
        ]);
    }
}
