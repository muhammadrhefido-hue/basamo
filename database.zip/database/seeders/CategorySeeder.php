<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class CategorySeeder extends Seeder
{
    use WithoutModelEvents;

    public function run(): void
    {
        $categories = [
            'Tempat Ibadah',
            'Restoran',
            'Rumah Sakit',
            'Taman',
            'Museum',
            'Perpustakaan',
            'Pemerintahan',
            'Hotel',
            'Bank',
            'Toko',
            'Kampus',
            'Transportasi',
        ];

        foreach ($categories as $category) {
            Category::create([
                'name' => $category,
                'slug' => Str::slug($category),
            ]);
        }
    }
}
