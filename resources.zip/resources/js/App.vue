<template>
  <div id="app">
    <template v-if="currentLayout === 'public'">
      <Header />
      <main>
        <RouterView />
      </main>
      <Footer />
    </template>
    <template v-else-if="currentLayout === 'admin'">
      <AdminHeader />
      <div class="flex">
        <AdminSidebar />
        <main class="flex-1">
          <RouterView />
        </main>
      </div>
    </template>
    <template v-else>
      <!-- Blank layout for login page -->
      <RouterView />
    </template>
  </div>
</template>

<script setup>
import { computed } from 'vue';
import { useRoute } from 'vue-router';
import Header from './components/public/Header.vue';
import Footer from './components/public/Footer.vue';
import AdminHeader from './components/admin/AdminHeader.vue';
import AdminSidebar from './components/admin/AdminSidebar.vue';

const route = useRoute();

const currentLayout = computed(() => {
  return route.meta.layout || 'public';
});
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html {
  scroll-behavior: smooth;
}

body {
  font-family: 'Poppins', sans-serif;
  background-color: #f8fafb;
}

#app {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}
</style>
