/**
 * Slug utility for converting text to URL-friendly slugs
 */
export const Slug = {
  /**
   * Convert text to slug
   * @param {string} text - Text to convert
   * @returns {string} - Slugified text
   */
  create(text) {
    if (!text) return '';

    return text
      .toString()
      .toLowerCase()
      .trim()
      // Replace spaces with hyphens
      .replace(/\s+/g, '-')
      // Replace special characters
      .replace(/[^\w\-]/g, '')
      // Replace multiple hyphens with single hyphen
      .replace(/\-\-+/g, '-')
      // Remove leading/trailing hyphens
      .replace(/^\-+|\-+$/g, '');
  }
};
