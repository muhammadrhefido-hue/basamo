import { defineStore } from 'pinia';
import { ref } from 'vue';
import { authService } from '../services/authService';

export const useAuthStore = defineStore('auth', () => {
    const token = ref(localStorage.getItem('admin_token'));
    const isAuthenticated = ref(!!token.value);
    const user = ref(null);
    const loading = ref(false);
    const error = ref(null);

    const login = async (email, password) => {
        loading.value = true;
        error.value = null;
        try {
            const response = await authService.login(email, password);
            token.value = response.token;
            isAuthenticated.value = true;
            return response;
        } catch (err) {
            error.value = err.response?.data?.message || 'Login gagal';
            isAuthenticated.value = false;
            throw err;
        } finally {
            loading.value = false;
        }
    };

    const logout = async () => {
        try {
            await authService.logout();
        } catch (err) {
            console.error('Logout error:', err);
        } finally {
            token.value = null;
            isAuthenticated.value = false;
            user.value = null;
        }
    };

    return {
        token,
        isAuthenticated,
        user,
        loading,
        error,
        login,
        logout,
    };
});
