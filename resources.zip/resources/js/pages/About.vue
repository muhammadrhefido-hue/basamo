<template>
  <div>

    <!-- About Content -->
    <section class="py-16 md:py-24 bg-white">
      <div class="max-w-4xl mx-auto px-6 space-y-12">
        <!-- What is BASAMO -->
        <div>
          <h2 class="text-2xl md:text-3xl font-bold text-primary mb-6">
            Apa itu BASAMO?
          </h2>
          <p class="text-lg text-gray-700 leading-relaxed text-justify">
            BASAMO adalah website direktori tempat-tempat ramah disabilitas di Kota Palembang yang menyediakan informasi lokasi publik yang telah disurvei dan diverifikasi langsung oleh tim BASAMO. Kami berkomitmen untuk memberikan akses informasi yang akurat dan terpercaya sehingga penyandang disabilitas dapat merencanakan aktivitas mereka dengan lebih percaya diri di Kota Palembang.
          </p>
        </div>

        <!-- Tujuan BASAMO -->
        <div class="bg-blue-50 p-8 rounded-xl">
          <h2 class="text-2xl md:text-3xl font-bold text-primary mb-6">
            Tujuan BASAMO
          </h2>
          <ul class="space-y-4 text-gray-700">
            <li class="flex items-start gap-4">
              <span class="text-3xl">🎯</span>
              <span class="text-lg text-justify">
                Menyediakan informasi terpercaya tentang aksesibilitas tempat-tempat publik di Kota Palembang
              </span>
            </li>
            <li class="flex items-start gap-4">
              <span class="text-3xl">🤝</span>
              <span class="text-lg text-justify">
                Memberdayakan penyandang disabilitas untuk berpartisipasi penuh dalam kehidupan sosial dan ekonomi
              </span>
            </li>
            <li class="flex items-start gap-4">
              <span class="text-3xl">🏙️</span>
              <span class="text-lg text-justify">
                Mendorong bisnis dan institusi publik untuk meningkatkan standar aksesibilitas mereka
              </span>
            </li>
            <li class="flex items-start gap-4">
              <span class="text-3xl">📱</span>
              <span class="text-lg text-justify">
                Menyediakan platform digital yang mudah diakses oleh semua orang
              </span>
            </li>
          </ul>
        </div>

        <!-- Misi -->
        <div class="bg-gradient-to-r from-primary to-primary-light text-white p-8 rounded-xl">
          <h2 class="text-2xl md:text-3xl font-bold mb-4">
            Misi BASAMO
          </h2>
          <p class="text-lg leading-relaxed text-justify">
            Membantu penyandang disabilitas memperoleh informasi aksesibilitas ruang publik secara mudah dan terpusat.
          </p>
        </div>

        <!-- Collaboration -->
        <div>
          <h2 class="text-2xl md:text-3xl font-bold text-primary mb-6">
            Kolaborasi
          </h2>
          <p class="text-gray-700 mb-6">
            BASAMO adalah hasil kolaborasi dengan:
          </p>

          <div class="bg-white border-2 border-primary rounded-xl p-8 flex flex-col md:flex-row items-center gap-8">
            <div class="w-full md:w-1/3 text-center">
              <img
                src="/logoyayasan.png"
                alt="Yayasan Sharing Disability Indonesia"
                class="w-40 h-40 object-contain mx-auto"
              />
            </div>
            <div class="w-full md:w-2/3">
              <h2 class="text-2xl font-bold text-primary mb-3">
                Yayasan Sharing Disability Indonesia
              </h2>
              <p class="text-gray-700 mb-6 text-justify">
                Yayasan Sharing Disability Indonesia adalah sebuah organisasi non-Pemerintah NON PROFIT (NGO) yang berkomitmen untuk memperjuangkan hak-hak penyandang disabilitas, termasuk hak atas pendidikan, pekerjaan, dan partisipasi sosial.
              </p>
              <a
                href="https://sharingdisabilityindonesia.org/"
                target="_blank"
                rel="noopener noreferrer"
                class="inline-block bg-primary text-white px-6 py-3 rounded-lg font-bold hover:bg-primary-light transition-colors flex justify-center"
              >
                Kunjungi Website
              </a>
            </div>
          </div>
        </div>

      </div>
    </section>
  </div>
</template>

<script setup>
// About page component
</script>
