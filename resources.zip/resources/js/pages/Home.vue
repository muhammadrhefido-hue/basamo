<template>
  <div>
    <!-- Hero Section -->
    <section class="bg-gradient-to-r from-primary via-blue-500 to-primary-light text-white py-16 md:py-20 relative overflow-hidden">
      <div class="absolute inset-0 opacity-10">
        <div class="absolute top-10 left-10 text-6xl animate-bounce">📍</div>
        <div class="absolute top-20 right-20 text-5xl animate-bounce" style="animation-delay: 0.2s">🏘️</div>
        <div class="absolute bottom-10 left-1/4 text-5xl animate-bounce" style="animation-delay: 0.4s">🌍</div>
      </div>
      <div class="max-w-7xl mx-auto px-6 relative z-10">
        <h1 class="text-4xl md:text-5xl font-bold mb-3 leading-tight text-center">
          BASAMO
        </h1>
        <p class="text-blue-100 text-lg md:text-xl text-center">
          Temukan Lokasi Ramah Disabilitas di Kota Palembang
        </p>
        <div class="mt-8 flex justify-center">
          <RouterLink
            to="/lokasi"
            class="inline-block bg-white text-primary px-8 py-4 rounded-lg font-bold text-lg hover:bg-blue-50 transition-colors shadow-md"
          >
            Jelajahi Lokasi
          </RouterLink>
        </div>
      </div>
    </section>

    <!-- Featured Locations Section -->
    <section class="py-12 md:py-24 bg-white overflow-hidden">
      <div class="max-w-7xl mx-auto px-4 md:px-6">
        <ChatBot />
      </div>
    </section>



    <!-- Call to Action Section -->
    <section class="bg-gradient-to-r from-primary to-primary-light text-white py-16">
      <div class="max-w-4xl mx-auto px-6 text-center">
        <h2 class="text-3xl md:text-4xl font-bold mb-6">
          Mulai Jelajahi Sekarang
        </h2>
        <p class="text-lg text-blue-100 mb-8">
          Temukan lokasi-lokasi ramah disabilitas yang telah diverifikasi oleh tim BASAMO dan nikmati pengalaman yang lebih mudah di Kota Palembang.
        </p>
        <RouterLink
          to="/lokasi"
          class="inline-block bg-white text-primary px-8 py-4 rounded-lg font-bold text-lg hover:bg-blue-50 transition-colors shadow-md"
        >
          Lihat Semua Lokasi
        </RouterLink>
      </div>
    </section>
  </div>
</template>

<script setup>
import { RouterLink } from 'vue-router';
import ChatBot from '../components/public/ChatBot.vue';
</script>
