<template>
  <div class="bg-gradient-to-b from-blue-50 to-white min-h-screen">
    <!-- Header -->
    <section class="bg-gradient-to-r from-primary via-blue-500 to-primary-light text-white py-16 md:py-20 relative overflow-hidden">
      <div class="absolute inset-0 opacity-10">
        <div class="absolute top-10 left-10 text-6xl animate-bounce">📍</div>
        <div class="absolute top-20 right-20 text-5xl animate-bounce" style="animation-delay: 0.2s">🏘️</div>
        <div class="absolute bottom-10 left-1/4 text-5xl animate-bounce" style="animation-delay: 0.4s">🌍</div>
      </div>
      <div class="max-w-7xl mx-auto px-6 relative z-10">
        <h1 class="text-4xl md:text-5xl font-bold mb-3 leading-tight text-center">
          Jelajahi Lokasi Ramah Disabilitas
        </h1>
        <p class="text-blue-100 text-lg md:text-xl text-center">
          Temukan berbagai tempat yang mudah diakses dan nyaman untuk semua orang
        </p>
      </div>
    </section>

    <!-- Categories Grid -->
    <section class="py-16 md:py-24">
      <div class="max-w-7xl mx-auto px-6">
        <!-- Loading State -->
        <div v-if="loading" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div v-for="i in 6" :key="i" class="bg-white rounded-2xl h-96 animate-pulse shadow-sm"></div>
        </div>

        <!-- Categories Display -->
        <div v-else-if="categories.length" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div
            v-for="category in categories"
            :key="category.id"
            class="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden flex flex-col cursor-pointer transform hover:-translate-y-2"
          >
            <!-- Icon Section -->
            <div class="relative h-56 bg-gradient-to-br from-primary/10 via-blue-100 to-primary/5 flex items-center justify-center text-8xl overflow-hidden">
              <!-- Background decoration -->
              <div class="absolute inset-0 opacity-20 group-hover:opacity-40 transition-opacity duration-300">
                <svg class="absolute w-full h-full" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="20" cy="30" r="15" fill="currentColor" class="text-primary"/>
                  <circle cx="80" cy="70" r="20" fill="currentColor" class="text-blue-400"/>
                  <path d="M 50 10 Q 70 20 80 40" stroke="currentColor" class="text-primary/30" stroke-width="2" fill="none"/>
                </svg>
              </div>
              <span class="text-8xl group-hover:scale-125 transition-transform duration-300 relative z-10">
                {{ getCategoryIcon(category.name) }}
              </span>
            </div>

            <!-- Content Section -->
            <div class="p-8 flex-1 flex flex-col">
              <h3 class="text-2xl font-bold text-gray-900 mb-3 group-hover:text-primary transition-colors duration-300 text-center">
                {{ category.name }}
              </h3>
              <p v-if="getCategoryDescription(category.name)" class="text-gray-600 mb-6 flex-1 leading-relaxed text-center">
                {{ getCategoryDescription(category.name) }}
              </p>

              <!-- Button -->
              <RouterLink
                :to="`/lokasi/${category.slug}`"
                class="inline-block w-full text-center bg-gradient-to-r from-primary to-blue-500 text-white px-6 py-4 rounded-xl font-bold hover:from-primary-light hover:to-blue-600 transition-all duration-300 shadow-button hover:shadow-button-lg transform hover:scale-105"
              >
                Lihat Lokasi
              </RouterLink>
            </div>
          </div>
        </div>

        <!-- Empty State -->
        <div v-else class="text-center py-20">
          <div class="text-6xl mb-4">📭</div>
          <p class="text-gray-500 text-xl font-medium">Belum ada kategori</p>
          <p class="text-gray-400 mt-2">Kembali lagi nanti untuk melihat berbagai kategori lokasi menarik</p>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { RouterLink } from 'vue-router';
import { categoryService } from '../services/categoryService';

const categories = ref([]);
const loading = ref(true);

onMounted(async () => {
  try {
    const data = await categoryService.getAll();
    categories.value = data;
  } catch (err) {
    console.error('Error fetching categories:', err);
  } finally {
    loading.value = false;
  }
});

const getCategoryIcon = (categoryName) => {
  const icons = {
    'Tempat Ibadah': '🙏',
    'Restoran': '🍽️',
    'Rumah Sakit': '🏥',
    'Taman': '🌳',
    'Museum': '🎨',
    'Perpustakaan': '📚',
    'Pemerintahan': '🏛️',
    'Hotel': '🏨',
    'Bank': '🏦',
    'Toko': '🛍️',
    'Kampus': '🎓',
    'Transportasi': '🚉',
  };
  return icons[categoryName] || '📍';
};

const getCategoryDescription = (categoryName) => {
  const descriptions = {
    'Tempat Ibadah': 'Tempat-tempat ibadah yang mudah diakses',
    'Restoran': 'Restoran dan kafe yang ramah untuk semua',
    'Rumah Sakit': 'Fasilitas kesehatan yang mendukung aksesibilitas',
    'Taman': 'Taman dan ruang terbuka yang nyaman',
    'Museum': 'Lembaga budaya yang inklusif',
    'Perpustakaan': 'Perpustakaan dengan fasilitas lengkap',
    'Pemerintahan': 'Kantor pemerintahan yang aksesibel',
    'Hotel': 'Akomodasi yang memenuhi standar aksesibilitas',
    'Bank': 'Layanan perbankan yang mudah diakses',
    'Toko': 'Toko dan mal dengan fasilitas baik',
    'Kampus': 'Institusi pendidikan yang inklusif',
    'Transportasi': 'Layanan transportasi publik yang aksesibel',
  };
  return descriptions[categoryName] || '';
};
</script>
