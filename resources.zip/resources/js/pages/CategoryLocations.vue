<template>
  <div class="bg-gradient-to-b from-white to-blue-50 min-h-screen">
    <!-- Header -->
    <section class="bg-gradient-to-r from-primary/95 via-blue-500 to-primary-light text-white py-12 relative overflow-hidden">
      <div class="absolute inset-0 opacity-5">
        <div class="absolute top-5 right-10 text-5xl animate-pulse">🎯</div>
        <div class="absolute bottom-5 left-10 text-4xl animate-pulse" style="animation-delay: 0.3s">📍</div>
      </div>
      <div class="max-w-7xl mx-auto px-6 relative z-10">
        <RouterLink to="/lokasi" class="text-blue-100 hover:text-white mb-4 inline-flex items-center gap-2 transition-colors">
          <span>←</span> Kembali ke Kategori
        </RouterLink>
        <h1 class="text-3xl md:text-4xl font-bold mt-4 mb-2 text-center">
          {{ categoryName }}
        </h1>
        
      </div>
    </section>

    <!-- Locations Grid -->
    <section class="py-16 md:py-24">
      <div class="max-w-7xl mx-auto px-6">
        <!-- Loading State -->
        <div v-if="loading" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div v-for="i in 6" :key="i" class="bg-white rounded-2xl h-96 animate-pulse shadow-md"></div>
        </div>

        <!-- Locations Display -->
        <div v-else-if="locations.length" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <RouterLink
            v-for="location in locations"
            :key="location.id"
            :to="`/lokasi/${categorySlug}/${location.slug}`"
            class="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden flex flex-col h-full cursor-pointer transform hover:-translate-y-2"
          >
            <!-- Image Section -->
            <div v-if="location.images?.length" class="relative bg-gray-200 overflow-hidden aspect-video">
              <img
                :src="location.images[0].image_url"
                :alt="location.name"
                class="w-full h-full object-contain group-hover:scale-110 transition-transform duration-300"
              >
              <!-- Overlay gradient -->
              <div class="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <!-- Badge -->
              <div class="absolute top-3 right-3 bg-white/95 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-primary">
                ✓ Terverifikasi
              </div>
            </div>
            <div v-else class="relative bg-gradient-to-br from-primary/20 via-blue-100 to-primary/10 flex items-center justify-center text-6xl aspect-video">
              {{ getCategoryIcon(categoryName) }}
            </div>

            <!-- Content Section -->
            <div class="p-6 flex-1 flex flex-col">
              <h3 class="font-bold text-lg md:text-xl text-gray-900 mb-2 group-hover:text-primary transition-colors line-clamp-2">
                {{ location.name }}
              </h3>

              <p class="text-sm text-gray-600 mb-4 flex-1 line-clamp-3 leading-relaxed">
                {{ location.description }}
              </p>

              <!-- Accessibility Info Preview -->
              <div v-if="location.accessibility_info" class="mb-4 text-xs text-green-700 bg-green-50 p-3 rounded-lg border border-green-200">
                <span class="font-bold block mb-1">♿ Aksesibilitas:</span>
                <p class="line-clamp-2">{{ truncateText(location.accessibility_info, 60) }}...</p>
              </div>

              <!-- Footer with arrow -->
              <div class="flex items-center justify-between pt-4 border-t border-gray-100">
                <span class="text-xs font-semibold text-primary">Lihat Detail</span>
                <span class="text-lg group-hover:translate-x-2 transition-transform duration-300">→</span>
              </div>
            </div>
          </RouterLink>
        </div>

        <!-- Empty State -->
        <div v-else class="text-center py-20">
          <div class="text-6xl mb-4 opacity-50">🔍</div>
          <p class="text-gray-500 text-xl font-medium">Belum ada lokasi di kategori ini</p>
          <p class="text-gray-400 mt-2">Lokasi akan ditambahkan segera</p>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRoute } from 'vue-router';
import { RouterLink } from 'vue-router';
import { categoryService } from '../services/categoryService';

const route = useRoute();
const categorySlug = ref(route.params.slug);
const categoryName = ref('');
const locations = ref([]);
const loading = ref(true);

onMounted(async () => {
  try {
    const data = await categoryService.getBySlug(categorySlug.value);
    categoryName.value = data.name;
    locations.value = data.locations || [];
  } catch (err) {
    console.error('Error fetching category:', err);
  } finally {
    loading.value = false;
  }
});

const getCategoryIcon = (categoryName) => {
  const icons = {
    'Tempat Ibadah': '🙏',
    'Restoran': '🍽️',
    'Rumah Sakit': '🏥',
    'Taman': '🌳',
    'Museum': '🎨',
    'Perpustakaan': '📚',
    'Pemerintahan': '🏛️',
    'Hotel': '🏨',
    'Bank': '🏦',
    'Toko': '🛍️',
    'Kampus': '🎓',
    'Transportasi': '🚌',
  };
  return icons[categoryName] || '📍';
};

const truncateText = (text, length) => {
  if (!text) return '';
  return text.substring(0, length).split('\n')[0];
};
</script>
