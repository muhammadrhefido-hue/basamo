<template>
  <div>
    <!-- Back Button & Breadcrumb -->
    <section class="bg-gradient-to-r from-blue-50 to-primary/5 border-b border-primary/10">
      <div class="max-w-7xl mx-auto px-6 py-6">
        <RouterLink :to="`/lokasi/${categorySlug}`" class="text-primary hover:text-primary-light font-semibold flex items-center gap-2 transition-colors">
          <span>← Kembali</span> ke {{ categoryName }}
        </RouterLink>
      </div>
    </section>

    <!-- Main Content -->
    <section v-if="!loading && location" class="py-16 md:py-24 bg-gradient-to-b from-white to-blue-50">
      <div class="max-w-7xl mx-auto px-6">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-10">
          <!-- Image Gallery -->
          <div class="lg:col-span-2">
            <!-- Main Image -->
            <div class="bg-gradient-to-br from-primary/5 to-blue-100 rounded-2xl overflow-hidden mb-6 shadow-lg">
              <div v-if="location.images.length" class="relative overflow-hidden bg-gray-200 aspect-video">
                <transition name="fade" mode="out-in">
                  <img
                    :key="currentImageIndex"
                    :src="location.images[currentImageIndex].image_url"
                    :alt="`${location.name} - Gambar ${currentImageIndex + 1}`"
                    class="w-full h-full object-contain"
                  />
                </transition>

                <!-- Image Navigation -->
                <div v-if="location.images.length > 1" class="absolute inset-0 flex items-center justify-between p-4 bg-black/20 opacity-0 hover:opacity-100 transition-opacity">
                  <button
                    @click="prevImage"
                    class="bg-white/90 hover:bg-white text-primary p-3 rounded-full transition-all transform hover:scale-110 font-bold text-xl shadow-lg"
                  >
                    ❮
                  </button>
                  <button
                    @click="nextImage"
                    class="bg-white/90 hover:bg-white text-primary p-3 rounded-full transition-all transform hover:scale-110 font-bold text-xl shadow-lg"
                  >
                    ❯
                  </button>
                </div>

                <!-- Image Indicator -->
                <div v-if="location.images.length > 1" class="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
                  <button
                    v-for="(img, idx) in location.images"
                    :key="idx"
                    @click="currentImageIndex = idx"
                    :class="{
                      'w-4 h-4 bg-white shadow-lg': idx === currentImageIndex,
                      'w-3 h-3 bg-white/50': idx !== currentImageIndex
                    }"
                    class="rounded-full transition-all hover:bg-white"
                  />
                </div>
              </div>
              <div v-else class="aspect-video flex items-center justify-center text-8xl bg-gradient-to-br from-primary/10 via-blue-100 to-primary/5">
                📍
              </div>
            </div>

            <!-- Image Thumbnails -->
            <div v-if="location.images.length > 1" class="grid grid-cols-4 gap-3 mb-8">
              <button
                v-for="(img, idx) in location.images"
                :key="idx"
                @click="currentImageIndex = idx"
                :class="{
                  'ring-3 ring-primary shadow-lg': idx === currentImageIndex,
                  'opacity-60 hover:opacity-100': idx !== currentImageIndex
                }"
                class="relative rounded-lg overflow-hidden transition-all transform hover:scale-105 aspect-video"
              >
                <img
                  :src="img.image_url"
                  :alt="`Thumbnail ${idx + 1}`"
                  class="w-full h-full object-contain"
                />
              </button>
            </div>

            <!-- Description -->
            <div class="bg-gradient-to-br from-blue-50 to-white p-8 rounded-2xl mb-8 border border-blue-100 shadow-sm">
              <h2 class="text-2xl font-bold text-primary mb-4 flex items-center gap-2">
                <span>📝</span> Deskripsi
              </h2>
              <p class="text-gray-700 leading-relaxed text-lg">
                {{ location.description }}
              </p>
            </div>

            <!-- Accessibility Info -->
            <div v-if="location.accessibility_info" class="bg-gradient-to-br from-green-50 to-emerald-50 border-l-4 border-success p-8 rounded-2xl mb-8 shadow-sm">
              <h2 class="text-2xl font-bold text-success mb-6 flex items-center gap-2">
                <span>♿</span> Informasi Aksesibilitas
              </h2>
              <div class="text-gray-700 space-y-4">
                <p v-for="(info, idx) in getAccessibilityPoints(location.accessibility_info)" :key="idx" class="flex items-start gap-4 text-base">
                  <span class="text-2xl flex-shrink-0">✓</span>
                  <span class="pt-1">{{ info }}</span>
                </p>
              </div>
            </div>

            <!-- Additional Notes -->
            <div v-if="location.notes" class="bg-gradient-to-br from-amber-50 to-yellow-50 border-l-4 border-warning p-8 rounded-2xl shadow-sm">
              <h2 class="text-2xl font-bold text-amber-900 mb-4 flex items-center gap-2">
                <span>📌</span> Catatan Penting
              </h2>
              <p class="text-gray-700 leading-relaxed text-base">
                {{ location.notes }}
              </p>
            </div>
          </div>

          <!-- Sidebar -->
          <div class="lg:col-span-1">
            <!-- Location Info Card -->
            <div class="bg-white rounded-2xl shadow-lg p-8 sticky top-24 space-y-6 border border-primary/5">
              <!-- Title & Category -->
              <div>
                <h1 class="text-3xl font-bold text-gray-900 mb-3">
                  {{ location.name }}
                </h1>
                <p class="text-primary font-bold flex items-center gap-2">
                  <span>{{ getCategoryIcon(categoryName) }}</span>
                  {{ categoryName }}
                </p>
              </div>

              <!-- Divider -->
              <div class="border-t border-gray-100"></div>

              <!-- Location Status -->
              <div v-if="location.is_published" class="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-xl border border-green-200">
                <p class="text-sm text-green-800 font-bold flex items-center gap-2">
                  <span class="text-lg">✓</span> Lokasi Terverifikasi
                </p>
              </div>

              <!-- Visit Button -->
              <a
                v-if="location.google_maps_url"
                :href="location.google_maps_url"
                target="_blank"
                rel="noopener noreferrer"
                class="block w-full bg-gradient-to-r from-primary to-blue-500 text-white text-center px-6 py-4 rounded-xl font-bold hover:from-primary-light hover:to-blue-600 transition-all shadow-button hover:shadow-lg transform hover:scale-105"
              >
                🗺️ Buka di Google Maps
              </a>

              <!-- Quick Info -->
              <div class="space-y-3 text-sm">
                <div class="bg-gradient-to-r from-blue-50 to-primary/5 p-4 rounded-lg border border-blue-100">
                  <p class="text-gray-500 text-xs font-bold mb-2 uppercase tracking-wide">Kategori</p>
                  <p class="text-gray-900 font-bold text-base">{{ categoryName }}</p>
                </div>

                <div class="bg-gradient-to-r from-amber-50 to-yellow-50 p-4 rounded-lg border border-amber-100">
                  <p class="text-gray-500 text-xs font-bold mb-2 uppercase tracking-wide">Status</p>
                  <p class="text-gray-900 font-bold text-base flex items-center gap-2">
                    <span class="inline-block w-3 h-3 rounded-full" :class="location.is_published ? 'bg-green-500' : 'bg-gray-500'"></span>
                    {{ location.is_published ? 'Dipublikasikan' : 'Draft' }}
                  </p>
                </div>
              </div>

              
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Loading State -->
    <section v-else-if="loading" class="py-20 bg-white">
      <div class="max-w-7xl mx-auto px-6">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div class="lg:col-span-2 space-y-4">
            <div class="bg-gray-100 h-96 rounded-xl animate-pulse"></div>
            <div class="bg-gray-100 h-40 rounded-xl animate-pulse"></div>
          </div>
          <div class="bg-gray-100 h-64 rounded-xl animate-pulse"></div>
        </div>
      </div>
    </section>

    <!-- Error State -->
    <section v-else class="py-20 bg-white">
      <div class="max-w-7xl mx-auto px-6 text-center">
        <p class="text-gray-500 text-xl">Lokasi tidak ditemukan</p>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRoute } from 'vue-router';
import { RouterLink } from 'vue-router';
import { locationService } from '../services/locationService';
import { categoryService } from '../services/categoryService';

const route = useRoute();
const currentImageIndex = ref(0);
const location = ref(null);
const categoryName = ref('');
const categorySlug = ref(route.params.categorySlug);
const loading = ref(true);

onMounted(async () => {
  try {
    // Fetch location
    const locationData = await locationService.getBySlug(route.params.locationSlug);
    location.value = locationData;

    // Fetch category name if not in location
    if (locationData.category) {
      categoryName.value = locationData.category.name;
    }
  } catch (err) {
    console.error('Error fetching location:', err);
  } finally {
    loading.value = false;
  }
});

const nextImage = () => {
  if (location.value && location.value.images.length) {
    currentImageIndex.value = (currentImageIndex.value + 1) % location.value.images.length;
  }
};

const prevImage = () => {
  if (location.value && location.value.images.length) {
    currentImageIndex.value = (currentImageIndex.value - 1 + location.value.images.length) % location.value.images.length;
  }
};

const getAccessibilityPoints = (info) => {
  if (!info) return [];
  // Split by newline or bullet points
  return info.split('\n').filter(line => line.trim()).map(line => line.trim());
};

const getCategoryIcon = (categoryName) => {
  const icons = {
    'Tempat Ibadah': '🙏',
    'Restoran': '🍽️',
    'Rumah Sakit': '🏥',
    'Taman': '🌳',
    'Museum': '🎨',
    'Perpustakaan': '📚',
    'Pemerintahan': '🏛️',
    'Hotel': '🏨',
    'Bank': '🏦',
    'Toko': '🛍️',
    'Kampus': '🎓',
    'Transportasi': '🚌',
  };
  return icons[categoryName] || '📍';
};

const shareLocation = () => {
  const text = `Lihat ${location.value.name} di BASAMO - Temukan Lokasi Ramah Disabilitas di Kota Palembang!\n${window.location.href}`;

  if (navigator.share) {
    navigator.share({
      title: location.value.name,
      text: text,
      url: window.location.href,
    });
  } else {
    // Fallback: copy to clipboard
    navigator.clipboard.writeText(window.location.href);
    alert('Tautan disalin ke papan klip!');
  }
};
</script>

<style scoped>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
