<template>
  <div class="p-8">
    <!-- Page Title -->
    <div class="mb-8">
      <h1 class="text-4xl font-bold text-primary">Dashboard</h1>
      <p class="text-gray-600 mt-2">Selamat datang di portal administrasi BASAMO</p>
    </div>

    <!-- Stats Grid -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      <!-- Total Locations -->
      <div class="bg-white rounded-xl shadow-card p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-gray-600 text-sm font-medium">Total Lokasi</p>
            <p class="text-4xl font-bold text-primary mt-2">{{ totalLocations }}</p>
          </div>
          <div class="text-5xl">📍</div>
        </div>
      </div>

      <!-- Published Locations -->
      <div class="bg-white rounded-xl shadow-card p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-gray-600 text-sm font-medium">Lokasi Dipublikasikan</p>
            <p class="text-4xl font-bold text-success mt-2">{{ publishedLocations }}</p>
          </div>
          <div class="text-5xl">✅</div>
        </div>
      </div>

      <!-- Pending Locations -->
      <div class="bg-white rounded-xl shadow-card p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-gray-600 text-sm font-medium">Belum Dipublikasikan</p>
            <p class="text-4xl font-bold text-warning mt-2">{{ unpublishedLocations }}</p>
          </div>
          <div class="text-5xl">⏳</div>
        </div>
      </div>

      <!-- Total Categories -->
      <div class="bg-white rounded-xl shadow-card p-6">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-gray-600 text-sm font-medium">Total Kategori</p>
            <p class="text-4xl font-bold text-purple-600 mt-2">{{ totalCategories }}</p>
          </div>
          <div class="text-5xl">🏷️</div>
        </div>
      </div>
    </div>

    <!-- Quick Actions -->
    <div class="bg-white rounded-xl shadow-card p-8 mb-8">
      <h2 class="text-2xl font-bold text-primary mb-6">Tindakan Cepat</h2>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <RouterLink
          to="/admin/lokasi/tambah"
          class="block bg-primary hover:bg-primary-light text-white text-center py-4 px-6 rounded-lg font-bold transition-colors"
        >
          + Tambah Lokasi Baru
        </RouterLink>
        <RouterLink
          to="/admin/lokasi"
          class="block bg-blue-100 hover:bg-blue-200 text-primary text-center py-4 px-6 rounded-lg font-bold transition-colors"
        >
          📋 Kelola Lokasi
        </RouterLink>
        <RouterLink
          to="/admin/kategori"
          class="block bg-purple-100 hover:bg-purple-200 text-purple-900 text-center py-4 px-6 rounded-lg font-bold transition-colors"
        >
          🏷️ Kelola Kategori
        </RouterLink>
        <a
          href="/"
          class="block bg-gray-100 hover:bg-gray-200 text-gray-900 text-center py-4 px-6 rounded-lg font-bold transition-colors"
        >
          👁️ Lihat Website
        </a>
      </div>
    </div>

    <!-- Recent Activity -->
    <div class="bg-white rounded-xl shadow-card p-8">
      <h2 class="text-2xl font-bold text-primary mb-6">Informasi</h2>
      <div class="space-y-4">
        <div class="p-4 bg-blue-50 rounded-lg border-l-4 border-primary">
          <p class="text-sm text-gray-600">
            <span class="font-semibold">Admin Panel:</span> Anda dapat menambah, mengedit, dan menghapus lokasi dari halaman Kelola Lokasi.
          </p>
        </div>
        <div class="p-4 bg-blue-50 rounded-lg border-l-4 border-primary">
          <p class="text-sm text-gray-600">
            <span class="font-semibold">Publikasi:</span> Lokasi hanya akan muncul di website publik setelah diubah statusnya menjadi "Dipublikasikan".
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { RouterLink } from 'vue-router';
import { adminLocationService } from '../../services/adminLocationService';
import { adminCategoryService } from '../../services/adminCategoryService';

const totalLocations = ref(0);
const publishedLocations = ref(0);
const unpublishedLocations = ref(0);
const totalCategories = ref(0);

onMounted(async () => {
  try {
    const locations = await adminLocationService.getAll();
    totalLocations.value = locations.length;
    publishedLocations.value = locations.filter(l => l.is_published).length;
    unpublishedLocations.value = locations.filter(l => !l.is_published).length;

    const categories = await adminCategoryService.getAll();
    totalCategories.value = categories.length;
  } catch (err) {
    console.error('Error fetching data:', err);
  }
});
</script>
