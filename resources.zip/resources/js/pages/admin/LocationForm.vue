<template>
  <div class="p-8">
    <!-- Page Header -->
    <div class="mb-8">
      <RouterLink to="/admin/lokasi" class="text-primary hover:text-primary-light font-medium mb-4 inline-block">
        ← Kembali ke Daftar
      </RouterLink>
      <h1 class="text-4xl font-bold text-primary">
        {{ isEditing ? 'Edit Lokasi' : 'Tambah Lokasi Baru' }}
      </h1>
    </div>

    <!-- Form -->
    <div class="max-w-4xl">
      <form @submit.prevent="submitForm" class="space-y-8">
        <!-- Basic Information -->
        <div class="bg-white rounded-xl shadow-card p-8">
          <h2 class="text-2xl font-bold text-primary mb-6">Informasi Dasar</h2>

          <div class="space-y-6">
            <!-- Nama Lokasi -->
            <div>
              <label class="block text-sm font-semibold text-gray-900 mb-2">Nama Lokasi *</label>
              <input
                v-model="form.name"
                type="text"
                required
                class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-primary"
              />
            </div>

            <!-- Kategori -->
            <div>
              <label class="block text-sm font-semibold text-gray-900 mb-2">Kategori *</label>
              <select
                v-model="form.category_id"
                required
                class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-primary"
              >
                <option value="">Pilih Kategori</option>
                <option v-for="cat in categories" :key="cat.id" :value="cat.id">
                  {{ cat.name }}
                </option>
              </select>
            </div>

            <!-- Deskripsi -->
            <div>
              <label class="block text-sm font-semibold text-gray-900 mb-2">Deskripsi *</label>
              <textarea
                v-model="form.description"
                required
                rows="4"
                class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-primary"
              ></textarea>
            </div>
          </div>
        </div>

        <!-- Accessibility Information -->
        <div class="bg-white rounded-xl shadow-card p-8">
          <h2 class="text-2xl font-bold text-primary mb-6">♿ Informasi Aksesibilitas</h2>

          <div class="space-y-6">
            <!-- Accessibility Info -->
            <div>
              <label class="block text-sm font-semibold text-gray-900 mb-2">Detail Aksesibilitas *</label>
              <textarea
                v-model="form.accessibility_info"
                required
                rows="4"
                placeholder="Jelaskan fitur aksesibilitas yang tersedia (pisahkan dengan baris baru)"
                class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-primary"
              ></textarea>
              <p class="text-xs text-gray-600 mt-2">Contoh: Tersedia kursi roda lift, Toilet aksesibel, Jalur khusus difabel</p>
            </div>

            <!-- Notes -->
            <div>
              <label class="block text-sm font-semibold text-gray-900 mb-2">Catatan Tambahan</label>
              <textarea
                v-model="form.notes"
                rows="3"
                placeholder="Informasi tambahan yang berguna"
                class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-primary"
              ></textarea>
            </div>

            <!-- Google Maps URL -->
            <div>
              <label class="block text-sm font-semibold text-gray-900 mb-2">Link Google Maps</label>
              <input
                v-model="form.google_maps_url"
                type="url"
                placeholder="https://maps.google.com/..."
                class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-primary"
              />
            </div>

            <!-- Publish Status -->
            <div class="space-y-2">
              <div class="flex items-center">
                <input
                  v-model="form.is_published"
                  type="checkbox"
                  id="is_published"
                  class="w-5 h-5 rounded text-primary focus:ring-primary cursor-pointer accent-[#06668e]"
                />
                <label for="is_published" class="ml-3 text-sm font-semibold text-gray-900 cursor-pointer">
                  Publikasikan lokasi ini ke website publik
                </label>
              </div>
              <p class="text-xs text-gray-500">
                Centang opsi ini agar lokasi langsung tampil dan dapat dicari di website BASAMO.
              </p>
            </div>
          </div>
        </div>

        <!-- Images Section -->
        <div class="bg-white rounded-xl shadow-card p-8">
          <h2 class="text-2xl font-bold text-primary mb-6">📸 Gambar-Gambar</h2>

          <div class="space-y-6">
            <!-- Upload New Images -->
            <div class="border-2 border-dashed border-primary rounded-lg p-8 text-center cursor-pointer hover:bg-blue-50 transition-colors" @click="$refs.imageInput.click()">
              <input
                ref="imageInput"
                type="file"
                multiple
                accept="image/*"
                hidden
                @change="handleImageUpload"
              />
              <div class="text-4xl mb-3">📷</div>
              <p class="text-gray-700 font-medium">Klik atau seret gambar ke sini</p>
              <p class="text-gray-500 text-sm mt-1">Format: JPG, PNG, GIF, WEBP (Maks 15MB per gambar)</p>
            </div>

            <!-- Uploaded Images Preview -->
            <div v-if="form.new_images.length || (isEditing && form.images?.length)" class="grid grid-cols-3 gap-4">
              <!-- Existing Images -->
              <div v-if="isEditing && form.images?.length">
                <h3 class="font-semibold text-gray-900 mb-3 col-span-3">Gambar Saat Ini</h3>
              </div>
              <div
                v-for="(img, idx) in (isEditing && form.images ? form.images : [])"
                :key="`existing-${idx}`"
                class="relative group"
              >
                <img :src="img.image_url" :alt="img.image_url" class="w-full h-full object-contain rounded-lg aspect-video"/>
                <button
                  type="button"
                  @click="removeExistingImage(idx)"
                  class="absolute top-2 right-2 bg-red-500 text-white w-8 h-8 rounded-full flex items-center justify-center shadow-lg hover:bg-red-600 transition-colors z-10 font-bold"
                >
                  ✕
                </button>
              </div>

              <!-- New Images -->
              <div v-if="form.new_images.length">
                <h3 class="font-semibold text-gray-900 mb-3 col-span-3">Gambar Baru</h3>
              </div>
              <div
                v-for="(img, idx) in form.new_images"
                :key="`new-${idx}`"
                class="relative group"
              >
                <img :src="img.preview" :alt="img.file.name" class="w-full h-full object-contain rounded-lg aspect-video"/>
                <button
                  type="button"
                  @click="form.new_images.splice(idx, 1)"
                  class="absolute top-2 right-2 bg-red-500 text-white w-8 h-8 rounded-full flex items-center justify-center shadow-lg hover:bg-red-600 transition-colors z-10 font-bold"
                >
                  ✕
                </button>
              </div>
            </div>

            <div v-else class="text-center py-8 text-gray-500">
              <p>Belum ada gambar. Upload gambar untuk ditampilkan di halaman detail lokasi.</p>
            </div>
          </div>
        </div>

        <!-- Action Buttons -->
        <div class="flex gap-4">
          <button
            type="submit"
            :disabled="isLoading"
            class="flex-1 bg-primary hover:bg-primary-light disabled:bg-gray-400 text-white font-bold py-4 px-6 rounded-lg transition-colors"
          >
            <span v-if="!isLoading">
              {{ isEditing ? 'Simpan Perubahan' : 'Tambah Lokasi' }}
            </span>
            <span v-else>Sedang menyimpan...</span>
          </button>
          <RouterLink
            to="/admin/lokasi"
            class="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-900 font-bold py-4 px-6 rounded-lg text-center transition-colors"
          >
            Batal
          </RouterLink>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import { RouterLink } from 'vue-router';
import { adminLocationService, adminLocationImageService } from '../../services/adminLocationService';
import { categoryService } from '../../services/categoryService';

const router = useRouter();
const route = useRoute();
const isEditing = ref(!!route.params.id);

const categories = ref([]);
const isLoading = ref(false);
const imageInput = ref(null);
const pendingImageReads = ref(0);

const form = ref({
  name: '',
  category_id: '',
  description: '',
  accessibility_info: '',
  notes: '',
  google_maps_url: '',
  is_published: false,
  images: [],
  new_images: [],
});

// Computed property to track total images
const totalImages = computed(() => {
  const existingCount = form.value.images?.length || 0;
  const newCount = form.value.new_images?.length || 0;
  return existingCount + newCount;
});

onMounted(async () => {
  // Fetch categories
  try {
    const cats = await categoryService.getAll();
    categories.value = cats;
  } catch (err) {
    console.error('Error fetching categories:', err);
  }

  // If editing, fetch location data
  if (isEditing.value) {
    try {
      const location = await adminLocationService.getById(route.params.id);
      form.value = {
        ...form.value,
        ...location,
        images: location.images || [],
      };
    } catch (err) {
      console.error('Error fetching location:', err);
      alert('Gagal memuat data lokasi');
      router.push('/admin/lokasi');
    }
  }
});

const compressImage = (file, maxWidth = 1600, quality = 0.85) => {
  return new Promise((resolve) => {
    if (file.type === 'image/svg+xml' || file.type === 'image/gif') {
      resolve(file);
      return;
    }

    const img = new Image();
    const reader = new FileReader();

    reader.onload = (e) => {
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth || height > maxWidth) {
          if (width > height) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxWidth) / height);
            height = maxWidth;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);

        canvas.toBlob(
          (blob) => {
            if (blob && blob.size < file.size) {
              const newName = file.name.replace(/\.[^/.]+$/, "") + ".jpg";
              const compressedFile = new File([blob], newName, {
                type: 'image/jpeg',
                lastModified: Date.now(),
              });
              resolve(compressedFile);
            } else {
              resolve(file);
            }
          },
          'image/jpeg',
          quality
        );
      };
      img.onerror = () => resolve(file);
      img.src = e.target.result;
    };
    reader.onerror = () => resolve(file);
    reader.readAsDataURL(file);
  });
};

const handleImageUpload = async (e) => {
  const files = Array.from(e.target.files);
  if (!files.length) return;

  pendingImageReads.value += files.length;

  for (const file of files) {
    try {
      const processedFile = await compressImage(file);
      const reader = new FileReader();
      reader.onload = (event) => {
        form.value.new_images.push({
          file: processedFile,
          preview: event.target.result,
        });
        pendingImageReads.value -= 1;
      };
      reader.onerror = () => {
        pendingImageReads.value -= 1;
      };
      reader.readAsDataURL(processedFile);
    } catch (err) {
      console.error('Error processing image:', err);
      pendingImageReads.value -= 1;
    }
  }

  e.target.value = '';
};

const removeExistingImage = async (idx) => {
  const img = form.value.images[idx];
  if (!img || !img.id) {
    form.value.images.splice(idx, 1);
    return;
  }

  if (!confirm('Yakin ingin menghapus gambar ini?')) return;

  try {
    await adminLocationImageService.deleteImage(img.id);
    form.value.images.splice(idx, 1);
  } catch (err) {
    console.error('Error deleting image:', err);
    const msg = err.response?.data?.message || err.message || 'Terjadi kesalahan';
    alert('Gagal menghapus gambar: ' + msg);
  }
};

const submitForm = async () => {
  if (!form.value.name || !form.value.category_id || !form.value.description || !form.value.accessibility_info) {
    alert('Harap isi semua field yang wajib (ditandai *)');
    return;
  }

  // Wait for pending image reads to complete
  if (pendingImageReads.value > 0) {
    alert(`Masih ada ${pendingImageReads.value} gambar yang sedang diproses. Tunggu sebentar...`);
    return;
  }

  isLoading.value = true;

  try {
    let locationId = route.params.id;

    // Step 1: Save/Update location data
    if (isEditing.value) {
      await adminLocationService.update(route.params.id, {
        name: form.value.name,
        category_id: form.value.category_id,
        description: form.value.description,
        accessibility_info: form.value.accessibility_info,
        notes: form.value.notes,
        google_maps_url: form.value.google_maps_url,
        is_published: form.value.is_published ? 1 : 0,
      });
    } else {
      const created = await adminLocationService.create({
        name: form.value.name,
        category_id: form.value.category_id,
        description: form.value.description,
        accessibility_info: form.value.accessibility_info,
        notes: form.value.notes,
        google_maps_url: form.value.google_maps_url,
        is_published: form.value.is_published ? 1 : 0,
      });
      locationId = created.id;
    }

    // Step 2: Handle image uploads for new images (in parallel for maximum speed)
    let imageUploadErrors = [];
    if (form.value.new_images.length > 0) {
      const uploadPromises = form.value.new_images.map(async (imgData) => {
        try {
          await adminLocationImageService.uploadImage(locationId, imgData.file);
        } catch (imgErr) {
          console.error('Error uploading image:', imgErr);
          const serverMsg = imgErr.response?.data?.message || imgErr.message || 'Gagal upload';
          imageUploadErrors.push(`${imgData.file.name} (${serverMsg})`);
        }
      });
      await Promise.all(uploadPromises);
    }

    // Show appropriate message
    if (imageUploadErrors.length > 0) {
      alert(`Lokasi berhasil disimpan, tapi beberapa foto gagal diupload: ${imageUploadErrors.join(', ')}`);
    } else {
      alert(isEditing.value ? 'Lokasi berhasil diperbarui' : 'Lokasi berhasil ditambahkan');
    }

    router.push('/admin/lokasi');
  } catch (err) {
    console.error('Error saving location:', err);
    const errorMsg = err.response?.data?.message || err.message || 'Terjadi kesalahan';
    alert(isEditing.value ? `Gagal memperbarui lokasi: ${errorMsg}` : `Gagal menambah lokasi: ${errorMsg}`);
  } finally {
    isLoading.value = false;
  }
};
</script>
