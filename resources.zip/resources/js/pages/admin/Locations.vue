<template>
  <div class="p-8">
    <!-- Page Header -->
    <div class="flex items-center justify-between mb-8">
      <div>
        <h1 class="text-4xl font-bold text-primary">Kelola Lokasi</h1>
        <p class="text-gray-600 mt-2">Tambah, edit, atau hapus lokasi ramah disabilitas</p>
      </div>
      <RouterLink
        to="/admin/lokasi/tambah"
        class="bg-primary hover:bg-primary-light text-white px-6 py-3 rounded-lg font-bold transition-colors"
      >
        + Lokasi Baru
      </RouterLink>
    </div>

    <!-- Filters -->
    <div class="bg-white rounded-xl shadow-card p-6 mb-8">
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <input
          v-model="searchQuery"
          type="text"
          placeholder="Cari nama lokasi..."
          class="px-4 py-2 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-primary"
        />
        <select
          v-model="filterPublished"
          class="px-4 py-2 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-primary"
        >
          <option value="">Semua Status</option>
          <option value="true">Dipublikasikan</option>
          <option value="false">Belum Dipublikasikan</option>
        </select>
      </div>
    </div>

    <!-- Locations Table -->
    <div v-if="loading" class="bg-white rounded-xl shadow-card p-8">
      <div class="space-y-4">
        <div v-for="i in 5" :key="i" class="h-16 bg-gray-100 rounded-lg animate-pulse"></div>
      </div>
    </div>

    <div v-else-if="filteredLocations.length" class="bg-white rounded-xl shadow-card overflow-hidden">
      <div class="overflow-x-auto">
        <table class="w-full">
          <thead class="bg-blue-50 border-b-2 border-gray-200">
            <tr>
              <th class="px-6 py-4 text-left text-sm font-bold text-primary">Nama Lokasi</th>
              <th class="px-6 py-4 text-left text-sm font-bold text-primary">Kategori</th>
              <th class="px-6 py-4 text-left text-sm font-bold text-primary">Status</th>
              <th class="px-6 py-4 text-left text-sm font-bold text-primary">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="location in filteredLocations" :key="location.id" class="border-b border-gray-200 hover:bg-blue-50 transition-colors">
              <td class="px-6 py-4">
                <p class="font-semibold text-gray-900">{{ location.name }}</p>
              </td>
              <td class="px-6 py-4">
                <p class="text-gray-600">{{ location.category?.name || '-' }}</p>
              </td>
              <td class="px-6 py-4">
                <button
                  @click="togglePublish(location)"
                  :title="location.is_published ? 'Klik untuk jadikan Draft' : 'Klik untuk Publikasikan'"
                  class="cursor-pointer transition-transform hover:scale-105"
                >
                  <span
                    v-if="location.is_published"
                    class="inline-block bg-green-100 hover:bg-green-200 text-green-800 px-3 py-1 rounded-full text-sm font-semibold"
                  >
                    ✓ Dipublikasikan
                  </span>
                  <span
                    v-else
                    class="inline-block bg-yellow-100 hover:bg-yellow-200 text-yellow-800 px-3 py-1 rounded-full text-sm font-semibold"
                  >
                    ⏳ Belum (Draft)
                  </span>
                </button>
              </td>
              <td class="px-6 py-4">
                <div class="flex gap-2">
                  <button
                    @click="togglePublish(location)"
                    :class="location.is_published ? 'bg-yellow-100 hover:bg-yellow-200 text-yellow-800' : 'bg-green-100 hover:bg-green-200 text-green-800'"
                    class="px-3 py-1 rounded font-semibold text-sm transition-colors"
                  >
                    {{ location.is_published ? 'Unpublish' : 'Publish' }}
                  </button>
                  <RouterLink
                    :to="`/admin/lokasi/${location.id}/edit`"
                    class="bg-blue-100 hover:bg-blue-200 text-primary px-3 py-1 rounded font-semibold text-sm transition-colors"
                  >
                    Edit
                  </RouterLink>
                  <button
                    @click="deleteLocation(location.id)"
                    class="bg-red-100 hover:bg-red-200 text-danger px-3 py-1 rounded font-semibold text-sm transition-colors"
                  >
                    Hapus
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div v-else class="bg-white rounded-xl shadow-card p-12 text-center">
      <p class="text-gray-500 text-lg mb-6">Belum ada lokasi</p>
      <RouterLink
        to="/admin/lokasi/tambah"
        class="inline-block bg-primary hover:bg-primary-light text-white px-6 py-3 rounded-lg font-bold transition-colors"
      >
        Tambah Lokasi Pertama
      </RouterLink>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import { RouterLink } from 'vue-router';
import { adminLocationService } from '../../services/adminLocationService';

const locations = ref([]);
const loading = ref(true);
const searchQuery = ref('');
const filterPublished = ref('');

const filteredLocations = computed(() => {
  return locations.value.filter(location => {
    const matchesSearch = location.name.toLowerCase().includes(searchQuery.value.toLowerCase());
    const matchesFilter = filterPublished.value === '' ||
                          (filterPublished.value === 'true' ? location.is_published : !location.is_published);
    return matchesSearch && matchesFilter;
  });
});

onMounted(async () => {
  try {
    const data = await adminLocationService.getAll();
    locations.value = data;
  } catch (err) {
    console.error('Error fetching locations:', err);
  } finally {
    loading.value = false;
  }
});

const togglePublish = async (location) => {
  try {
    const response = await adminLocationService.publish(location.id);
    location.is_published = !location.is_published;
  } catch (err) {
    console.error('Error toggling publish status:', err);
    const msg = err.response?.data?.message || err.message || 'Terjadi kesalahan';
    alert('Gagal mengubah status publikasi: ' + msg);
  }
};

const deleteLocation = async (id) => {
  if (confirm('Apakah Anda yakin ingin menghapus lokasi ini?')) {
    try {
      await adminLocationService.delete(id);
      locations.value = locations.value.filter(l => l.id !== id);
      alert('Lokasi berhasil dihapus');
    } catch (err) {
      console.error('Error deleting location:', err);
      alert('Gagal menghapus lokasi');
    }
  }
};
</script>
