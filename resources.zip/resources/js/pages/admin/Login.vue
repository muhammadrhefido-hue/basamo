<template>
  <div class="min-h-screen bg-gradient-to-br from-primary to-primary-light flex items-center justify-center px-6">
    <div class="w-full max-w-md bg-white rounded-2xl shadow-2xl p-8">
      <!-- Header -->
      <div class="text-center mb-8">
        <div class="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center text-white text-3xl font-bold mx-auto mb-4">
          B
        </div>
        <h1 class="text-2xl font-bold text-gray-900">BASAMO Admin</h1>
        <p class="text-gray-600 mt-2">Portal Administrasi</p>
      </div>

      <!-- Login Form -->
      <form @submit.prevent="handleLogin" class="space-y-6">
        <!-- Email -->
        <div>
          <label for="email" class="block text-sm font-semibold text-gray-900 mb-2">
            Email
          </label>
          <input
            v-model="form.email"
            type="email"
            id="email"
            placeholder="admin@example.com"
            required
            class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-primary transition-colors"
          />
        </div>

        <!-- Password -->
        <div>
          <label for="password" class="block text-sm font-semibold text-gray-900 mb-2">
            Password
          </label>
          <input
            v-model="form.password"
            type="password"
            id="password"
            placeholder="••••••••"
            required
            class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-primary transition-colors"
          />
        </div>

        <!-- Error Message -->
        <div v-if="error" class="bg-red-50 border-l-4 border-danger p-4 rounded">
          <p class="text-sm text-red-800">{{ error }}</p>
        </div>

        <!-- Submit Button -->
        <button
          type="submit"
          :disabled="isLoading"
          class="w-full bg-primary hover:bg-primary-light disabled:bg-gray-400 text-white font-bold py-3 px-4 rounded-lg transition-colors"
        >
          <span v-if="!isLoading">Masuk</span>
          <span v-else>Sedang memproses...</span>
        </button>
      </form>

      <!-- Footer -->
      <div class="mt-8 pt-8 border-t border-gray-200 text-center">
        <p class="text-sm text-gray-600">
          Hanya untuk administrator BASAMO
        </p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import { useAuthStore } from '../../stores/authStore';

const router = useRouter();
const route = useRoute();
const authStore = useAuthStore();

const form = ref({
  email: '',
  password: '',
});

const isLoading = ref(false);
const error = ref('');

const handleLogin = async () => {
  error.value = '';
  isLoading.value = true;

  try {
    await authStore.login(form.value.email, form.value.password);
    const redirect = route.query.redirect || '/admin';
    router.push(redirect);
  } catch (err) {
    error.value = authStore.error || 'Login gagal. Periksa email dan password Anda.';
  } finally {
    isLoading.value = false;
  }
};
</script>
