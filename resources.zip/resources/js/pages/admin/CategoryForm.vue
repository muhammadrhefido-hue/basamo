<template>
  <div class="p-8">
    <!-- Page Header -->
    <div class="mb-8">
      <router-link
        to="/admin/kategori"
        class="text-primary hover:text-primary-light font-medium mb-4 inline-block"
      >
        ← Kembali ke Daftar
      </router-link>
      <h1 class="text-4xl font-bold text-primary">
        {{ isEditing ? 'Edit Kategori' : 'Tambah Kategori Baru' }}
      </h1>
    </div>

    <!-- Form -->
    <div class="max-w-2xl">
      <form @submit.prevent="submitForm" class="bg-white rounded-xl shadow-card p-8 space-y-6">
        <div>
          <label class="block text-sm font-semibold text-gray-900 mb-2">
            Nama Kategori *
          </label>
          <input
            v-model="form.name"
            type="text"
            placeholder="Contoh: Tempat Ibadah"
            class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-primary"
            required
          />
        </div>

        <div v-if="form.name" class="bg-blue-50 p-4 rounded-lg border-2 border-blue-200">
          <p class="text-sm font-semibold text-gray-900 mb-2">Slug Kategori:</p>
          <code class="text-sm bg-white border-2 border-gray-200 px-3 py-2 rounded block text-gray-700 font-mono">
            {{ slugPreview }}
          </code>
          <p class="text-xs text-gray-600 mt-2">Slug otomatis dibuat dari nama kategori</p>
        </div>

        <div class="flex gap-3 pt-4">
          <button
            type="submit"
            :disabled="isLoading"
            class="flex-1 px-6 py-3 bg-primary hover:bg-primary-light text-white rounded-lg font-semibold transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {{ isLoading ? 'Menyimpan...' : (isEditing ? 'Simpan Perubahan' : 'Tambah Kategori') }}
          </button>
          <router-link
            to="/admin/kategori"
            class="flex-1 px-6 py-3 border-2 border-gray-200 text-primary rounded-lg hover:bg-gray-50 text-center font-semibold transition"
          >
            Batal
          </router-link>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import { adminCategoryService } from '@/services/adminCategoryService';
import { Slug } from '@/utils/slug';

const router = useRouter();
const route = useRoute();
const isLoading = ref(false);

const form = ref({
  name: '',
});

const isEditing = computed(() => !!route.params.id);

const slugPreview = computed(() => {
  return Slug.create(form.value.name);
});

const loadCategory = async () => {
  try {
    const data = await adminCategoryService.getById(route.params.id);
    form.value = {
      name: data.name,
    };
  } catch (err) {
    console.error('Error loading category:', err);
    alert('Gagal memuat kategori');
    router.push('/admin/kategori');
  }
};

const submitForm = async () => {
  if (!form.value.name.trim()) {
    alert('Harap isi nama kategori');
    return;
  }

  isLoading.value = true;
  try {
    if (isEditing.value) {
      await adminCategoryService.update(route.params.id, form.value);
      alert('Kategori berhasil diperbarui');
    } else {
      await adminCategoryService.create(form.value);
      alert('Kategori berhasil dibuat');
    }
    router.push('/admin/kategori');
  } catch (err) {
    if (err.response?.data?.message) {
      alert(err.response.data.message);
    } else {
      alert(isEditing.value ? 'Gagal memperbarui kategori' : 'Gagal membuat kategori');
    }
    console.error('Error submitting form:', err);
  } finally {
    isLoading.value = false;
  }
};

onMounted(() => {
  if (isEditing.value) {
    loadCategory();
  }
});
</script>
