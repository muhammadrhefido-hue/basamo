<template>
  <div class="p-8">
    <!-- Page Header -->
    <div class="flex items-center justify-between mb-8">
      <div>
        <h1 class="text-4xl font-bold text-primary">Kelola Kategori</h1>
        <p class="text-gray-600 mt-2">Tambah, edit, atau hapus kategori lokasi</p>
      </div>
      <router-link
        to="/admin/kategori/tambah"
        class="bg-primary hover:bg-primary-light text-white px-6 py-3 rounded-lg font-bold transition-colors"
      >
        + Kategori Baru
      </router-link>
    </div>

    <!-- Filters -->
    <div class="bg-white rounded-xl shadow-card p-6 mb-8">
      <input
        v-model="searchQuery"
        type="text"
        placeholder="Cari nama kategori..."
        class="w-full px-4 py-2 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-primary"
      />
    </div>

    <!-- Categories Table -->
    <div v-if="isLoading" class="bg-white rounded-xl shadow-card p-8">
      <div class="space-y-4">
        <div v-for="i in 5" :key="i" class="h-16 bg-gray-100 rounded-lg animate-pulse"></div>
      </div>
    </div>

    <div v-else-if="filteredCategories.length" class="bg-white rounded-xl shadow-card overflow-hidden">
      <div class="overflow-x-auto">
        <table class="w-full">
          <thead class="bg-blue-50 border-b-2 border-gray-200">
            <tr>
              <th class="px-6 py-4 text-left text-sm font-bold text-primary">Nama Kategori</th>
              <th class="px-6 py-4 text-left text-sm font-bold text-primary">Slug</th>
              <th class="px-6 py-4 text-left text-sm font-bold text-primary">Jumlah Lokasi</th>
              <th class="px-6 py-4 text-left text-sm font-bold text-primary">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="category in filteredCategories" :key="category.id" class="border-b border-gray-200 hover:bg-blue-50 transition-colors">
              <td class="px-6 py-4">
                <p class="font-semibold text-gray-900">{{ category.name }}</p>
              </td>
              <td class="px-6 py-4">
                <code class="text-sm text-gray-600 bg-gray-100 px-2 py-1 rounded">{{ category.slug }}</code>
              </td>
              <td class="px-6 py-4">
                <span class="inline-block px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-semibold">
                  {{ category.locations_count }} lokasi
                </span>
              </td>
              <td class="px-6 py-4">
                <div class="flex gap-2">
                  <router-link
                    :to="`/admin/kategori/${category.id}/edit`"
                    class="bg-blue-100 hover:bg-blue-200 text-primary px-3 py-1 rounded font-semibold text-sm transition-colors"
                  >
                    Edit
                  </router-link>
                  <button
                    @click="deleteCategory(category.id, category.name)"
                    class="bg-red-100 hover:bg-red-200 text-danger px-3 py-1 rounded font-semibold text-sm transition-colors"
                  >
                    Hapus
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div v-else class="bg-white rounded-xl shadow-card p-12 text-center">
      <p class="text-gray-500 text-lg mb-6">Belum ada kategori</p>
      <router-link
        to="/admin/kategori/tambah"
        class="inline-block bg-primary hover:bg-primary-light text-white px-6 py-3 rounded-lg font-bold transition-colors"
      >
        Tambah Kategori Pertama
      </router-link>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import { adminCategoryService } from '@/services/adminCategoryService';
import { useRouter } from 'vue-router';

const router = useRouter();
const categories = ref([]);
const searchQuery = ref('');
const isLoading = ref(false);

const filteredCategories = computed(() => {
  return categories.value.filter(category =>
    category.name.toLowerCase().includes(searchQuery.value.toLowerCase())
  );
});

const loadCategories = async () => {
  isLoading.value = true;
  try {
    const data = await adminCategoryService.getAll();
    categories.value = data;
  } catch (err) {
    console.error('Error loading categories:', err);
    alert('Gagal memuat kategori');
  } finally {
    isLoading.value = false;
  }
};

const deleteCategory = async (id, name) => {
  if (!confirm(`Apakah Anda yakin ingin menghapus kategori "${name}"?`)) {
    return;
  }

  try {
    await adminCategoryService.delete(id);
    alert('Kategori berhasil dihapus');
    await loadCategories();
  } catch (err) {
    if (err.response?.data?.message) {
      alert(err.response.data.message);
    } else {
      alert('Gagal menghapus kategori');
    }
    console.error('Error deleting category:', err);
  }
};

onMounted(() => {
  loadCategories();
});
</script>
