import { createRouter, createWebHistory } from 'vue-router';
import { useAuthStore } from './stores/authStore';

// Public pages
import Home from './pages/Home.vue';
import Categories from './pages/Categories.vue';
import CategoryLocations from './pages/CategoryLocations.vue';
import LocationDetail from './pages/LocationDetail.vue';
import About from './pages/About.vue';

// Admin pages
import AdminLogin from './pages/admin/Login.vue';
import AdminDashboard from './pages/admin/Dashboard.vue';
import AdminLocations from './pages/admin/Locations.vue';
import AdminLocationForm from './pages/admin/LocationForm.vue';
import AdminCategoryList from './pages/admin/CategoryList.vue';
import AdminCategoryForm from './pages/admin/CategoryForm.vue';

const router = createRouter({
    history: createWebHistory(),
    routes: [
        // Public routes
        {
            path: '/',
            name: 'home',
            component: Home,
            meta: { layout: 'public' }
        },
        {
            path: '/lokasi',
            name: 'categories',
            component: Categories,
            meta: { layout: 'public' }
        },
        {
            path: '/lokasi/:slug',
            name: 'categoryLocations',
            component: CategoryLocations,
            meta: { layout: 'public' }
        },
        {
            path: '/lokasi/:categorySlug/:locationSlug',
            name: 'locationDetail',
            component: LocationDetail,
            meta: { layout: 'public' }
        },
        {
            path: '/tentang',
            name: 'about',
            component: About,
            meta: { layout: 'public' }
        },

        // Admin routes
        {
            path: '/admin/login',
            name: 'adminLogin',
            component: AdminLogin,
            meta: { layout: 'blank' }
        },
        {
            path: '/admin',
            name: 'adminDashboard',
            component: AdminDashboard,
            meta: { layout: 'admin', requiresAuth: true }
        },
        {
            path: '/admin/lokasi',
            name: 'adminLocations',
            component: AdminLocations,
            meta: { layout: 'admin', requiresAuth: true }
        },
        {
            path: '/admin/lokasi/tambah',
            name: 'adminLocationCreate',
            component: AdminLocationForm,
            meta: { layout: 'admin', requiresAuth: true }
        },
        {
            path: '/admin/lokasi/:id/edit',
            name: 'adminLocationEdit',
            component: AdminLocationForm,
            meta: { layout: 'admin', requiresAuth: true }
        },
        {
            path: '/admin/kategori',
            name: 'adminCategories',
            component: AdminCategoryList,
            meta: { layout: 'admin', requiresAuth: true }
        },
        {
            path: '/admin/kategori/tambah',
            name: 'adminCategoryCreate',
            component: AdminCategoryForm,
            meta: { layout: 'admin', requiresAuth: true }
        },
        {
            path: '/admin/kategori/:id/edit',
            name: 'adminCategoryEdit',
            component: AdminCategoryForm,
            meta: { layout: 'admin', requiresAuth: true }
        },
    ],
    scrollBehavior() {
        return { top: 0 };
    }
});

// Navigation guard for protected routes
router.beforeEach((to, from, next) => {
    const authStore = useAuthStore();

    if (to.meta.requiresAuth && !authStore.isAuthenticated) {
        next({ name: 'adminLogin', query: { redirect: to.fullPath } });
    } else if (to.name === 'adminLogin' && authStore.isAuthenticated) {
        next({ name: 'adminDashboard' });
    } else {
        next();
    }
});

export default router;
