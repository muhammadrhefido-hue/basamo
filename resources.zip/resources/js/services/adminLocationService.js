import api from './api';

export const adminLocationService = {
    // Get all locations (admin)
    getAll() {
        return api.get('/admin/locations').then(response => response.data.data);
    },

    // Get location by id (admin)
    getById(id) {
        return api.get(`/admin/locations/${id}`).then(response => response.data.data);
    },

    // Create new location
    create(data) {
        return api.post('/admin/locations', data).then(response => response.data.data);
    },

    // Update location
    update(id, data) {
        return api.put(`/admin/locations/${id}`, data).then(response => response.data.data);
    },

    // Publish location
    publish(id) {
        return api.patch(`/admin/locations/${id}/publish`).then(response => response.data.data);
    },

    // Delete location
    delete(id) {
        return api.delete(`/admin/locations/${id}`).then(response => response.data);
    },
};

export const adminLocationImageService = {
    // Upload image for location
    uploadImage(locationId, file) {
        const formData = new FormData();
        const filename = file.name || 'image.jpg';
        formData.append('image', file, filename);
        return api.post(`/admin/locations/${locationId}/images`, formData).then(response => response.data.data);
    },

    // Delete location image
    deleteImage(imageId) {
        return api.delete(`/admin/locations/images/${imageId}`).then(response => response.data);
    },
};
