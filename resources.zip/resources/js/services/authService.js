import api from './api';

export const authService = {
    // Admin login
    login(email, password) {
        return api.post('/admin/login', { email, password }).then(response => {
            if (response.data.data?.token) {
                localStorage.setItem('admin_token', response.data.data.token);
            }
            return response.data.data;
        });
    },

    // Admin logout
    logout() {
        return api.post('/admin/logout').then(response => {
            localStorage.removeItem('admin_token');
            return response.data;
        });
    },

    // Get token from localStorage
    getToken() {
        return localStorage.getItem('admin_token');
    },

    // Check if logged in
    isAuthenticated() {
        return !!localStorage.getItem('admin_token');
    },
};
