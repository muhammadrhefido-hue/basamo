import api from './api';

export const adminCategoryService = {
  /**
   * Get all categories
   */
  getAll() {
    return api
      .get('/admin/categories')
      .then(res => {
        if (res.data.success) {
          return res.data.data;
        }
        throw new Error(res.data.message || 'Failed to fetch categories');
      })
      .catch(error => {
        throw error;
      });
  },

  /**
   * Get single category by ID
   */
  getById(id) {
    return api
      .get(`/admin/categories/${id}`)
      .then(res => {
        if (res.data.success) {
          return res.data.data;
        }
        throw new Error(res.data.message || 'Category not found');
      })
      .catch(error => {
        throw error;
      });
  },

  /**
   * Create new category
   */
  create(data) {
    return api
      .post('/admin/categories', data)
      .then(res => {
        if (res.data.success) {
          return res.data.data;
        }
        throw new Error(res.data.message || 'Failed to create category');
      })
      .catch(error => {
        throw error;
      });
  },

  /**
   * Update category
   */
  update(id, data) {
    return api
      .put(`/admin/categories/${id}`, data)
      .then(res => {
        if (res.data.success) {
          return res.data.data;
        }
        throw new Error(res.data.message || 'Failed to update category');
      })
      .catch(error => {
        throw error;
      });
  },

  /**
   * Delete category
   */
  delete(id) {
    return api
      .delete(`/admin/categories/${id}`)
      .then(res => {
        if (res.data.success) {
          return res.data.data;
        }
        throw new Error(res.data.message || 'Failed to delete category');
      })
      .catch(error => {
        throw error;
      });
  }
};
