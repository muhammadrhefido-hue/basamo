import api from './api';

export const categoryService = {
    // Get all categories
    getAll() {
        return api.get('/categories').then(response => response.data.data);
    },

    // Get category with locations by slug
    getBySlug(slug) {
        return api.get(`/categories/${slug}`).then(response => response.data.data);
    },
};
