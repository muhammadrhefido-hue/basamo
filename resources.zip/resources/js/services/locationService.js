import api from './api';

export const locationService = {
    // Get location by slug with all details
    getBySlug(slug) {
        return api.get(`/locations/${slug}`).then(response => response.data.data);
    },
};
