<template>
  <footer class="bg-primary-dark text-white mt-20 pt-12 pb-6">
    <div class="max-w-7xl mx-auto px-6">
      <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
        <!-- About -->
        <div>
          <h3 class="font-bold text-lg mb-4 flex items-center gap-2">
            <img src="/logo.png" alt="BASAMO Logo" class="h-8 w-auto">
            BASAMO
          </h3>
          <p class="text-blue-100 text-sm leading-relaxed">
            Membantu penyandang disabilitas memperoleh informasi aksesibilitas ruang publik secara mudah dan terpusat.
          </p>
        </div>

        <!-- Quick Links -->
        <div>
          <h3 class="font-bold text-lg mb-4">Menu</h3>
          <ul class="space-y-2 text-blue-100">
            <li>
              <RouterLink to="/" class="hover:text-white transition-colors">
                Beranda
              </RouterLink>
            </li>
            <li>
              <RouterLink to="/lokasi" class="hover:text-white transition-colors">
                Lokasi
              </RouterLink>
            </li>
            <li>
              <RouterLink to="/tentang" class="hover:text-white transition-colors">
                Tentang
              </RouterLink>
            </li>
          </ul>
        </div>

        <!-- Contact Info -->
        <div>
          <h3 class="font-bold text-lg mb-4">Kontak</h3>
          <p class="text-blue-100 text-sm">
            Kolaborasi dengan Yayasan Sharing Disability Indonesia
          </p>
        </div>
      </div>

      <!-- Divider -->
      <div class="border-t border-primary-light py-6">
        <p class="text-center text-blue-100 text-sm">
          © 2026 BASAMO. Semua hak dilindungi.
        </p>
      </div>
    </div>
  </footer>
</template>

<script setup>
import { RouterLink } from 'vue-router';
</script>
