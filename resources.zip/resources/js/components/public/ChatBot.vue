<template>
  <div class="bg-gradient-to-r from-purple-50 to-blue-50 rounded-2xl shadow-lg p-4 md:p-8 w-full overflow-hidden">
    <!-- Header -->
    <div class="mb-6">
      <h3 class="text-2xl font-bold text-primary mb-2 flex items-center gap-2">
        💬 WAKSAMO BOT
      </h3>
      <p class="text-gray-600">
        Tanya langsung tentang lokasi ramah disabilitas di Palembang!
      </p>
    </div>

    <!-- Chat Box -->
    <div class="bg-white rounded-xl border-2 border-primary/20 mb-4 h-72 md:h-96 flex flex-col">
      <!-- Messages -->
      <div class="flex-1 overflow-y-auto p-4 space-y-4">
        <!-- Initial Message -->
        <div v-if="messages.length === 0" class="flex items-center justify-center h-full text-center text-gray-500">
          <div>
            <div class="text-6xl mb-3">🤖</div>
            <p class="font-semibold mb-2">Halo! Saya WAKSAMO!</p>
            <p class="text-sm">Tanya saya tentang lokasi ramah disabilitas di Palembang yang sudah diverifikasi Tim BASAMO.</p>
            <p class="text-xs mt-2 text-gray-400">Contoh: "Ada tempat ibadah ramah disabilitas di daerah Sako?"</p>
          </div>
        </div>

        <!-- Messages List -->
        <div v-for="(msg, idx) in messages" :key="idx" class="space-y-2">
          <!-- User Message -->
          <div v-if="msg.role === 'user'" class="flex justify-end">
            <div class="bg-primary text-white rounded-xl rounded-tr-none px-4 py-2 max-w-[75%]">
              <p class="text-sm">{{ msg.content }}</p>
            </div>
          </div>
          <!-- Bot Message -->
          <div v-else class="flex justify-start">
            <div class="bg-gray-100 text-gray-900 rounded-xl rounded-tl-none px-4 py-2 max-w-[75%]">
              <p class="text-sm">{{ msg.content }}</p>
            </div>
          </div>
        </div>

        <!-- Loading -->
        <div v-if="isLoading" class="flex justify-start">
          <div class="bg-gray-100 text-gray-900 rounded-xl rounded-tl-none px-4 py-3">
            <div class="flex gap-2">
              <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
              <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style="animation-delay: 0.1s"></div>
              <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style="animation-delay: 0.2s"></div>
            </div>
          </div>
        </div>

        <!-- Error -->
        <div v-if="errorMessage" class="flex justify-start">
          <div class="bg-red-100 text-red-900 rounded-xl rounded-tl-none px-4 py-2 max-w-[75%]">
            <p class="text-sm">⚠️ {{ errorMessage }}</p>
          </div>
        </div>
      </div>

      <!-- Input Area -->
      <div class="border-t-2 border-primary/10 p-2 md:p-4">
        <div class="flex gap-1 md:gap-2 w-full">
          <input
            v-model="userInput"
            @keyup.enter="sendMessage"
            :disabled="isLoading"
            type="text"
            placeholder="Tulis pertanyaan Anda..."
            class="flex-1 min-w-0 px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:border-primary disabled:bg-gray-100"
          />
          <button
            @click="sendMessage"
            :disabled="isLoading || !userInput.trim()"
            class="flex-shrink-0 bg-primary text-white px-3 py-2 rounded-lg font-bold hover:bg-primary-light transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed text-lg"
          >
            <span v-if="!isLoading">📤</span>
            <span v-else>⏳</span>
          </button>
        </div>
      </div>
    </div>

    <!-- Info -->
    <div class="text-xs text-gray-500 text-center">
      Powered by Groq API (100% Free & Unlimited) | Data dari lokasi terverifikasi BASAMO
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';

const messages = ref([]);
const userInput = ref('');
const isLoading = ref(false);
const errorMessage = ref('');

const sendMessage = async () => {
  if (!userInput.value.trim()) return;

  // Add user message
  const userMsg = userInput.value;
  messages.value.push({
    role: 'user',
    content: userMsg
  });

  userInput.value = '';
  isLoading.value = true;
  errorMessage.value = '';

  try {
    // Call backend API
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest'
      },
      body: JSON.stringify({
        message: userMsg
      })
    });

    const data = await response.json();

    if (!response.ok) {
      const errMsg = data?.error || 'Gagal menghubungi server';
      throw new Error(errMsg);
    }

    // Add bot message
    messages.value.push({
      role: 'assistant',
      content: data.response || 'Maaf, saya tidak bisa memahami pertanyaan Anda.'
    });

  } catch (err) {
    console.error('Chat error:', err);
    const errDetail = err.message || 'Tidak diketahui';
    errorMessage.value = 'Terjadi kesalahan: ' + errDetail;
    messages.value.push({
      role: 'assistant',
      content: 'Maaf, terjadi kesalahan: ' + errDetail
    });
  } finally {
    isLoading.value = false;
  }
};
</script>
