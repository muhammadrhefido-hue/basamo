<template>
  <RouterLink
    :to="to"
    class="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden flex flex-col cursor-pointer transform hover:-translate-y-2"
  >
    <!-- Icon Section -->
    <div class="relative h-56 bg-gradient-to-br from-primary/10 via-blue-100 to-primary/5 flex items-center justify-center text-8xl overflow-hidden">
      <!-- Background decoration -->
      <div class="absolute inset-0 opacity-20 group-hover:opacity-40 transition-opacity duration-300">
        <svg class="absolute w-full h-full" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
          <circle cx="20" cy="30" r="15" fill="currentColor" class="text-primary"/>
          <circle cx="80" cy="70" r="20" fill="currentColor" class="text-blue-400"/>
          <path d="M 50 10 Q 70 20 80 40" stroke="currentColor" class="text-primary/30" stroke-width="2" fill="none"/>
        </svg>
      </div>
      <span class="text-8xl group-hover:scale-125 transition-transform duration-300 relative z-10">
        {{ icon }}
      </span>
    </div>

    <!-- Content Section -->
    <div class="p-8 flex-1 flex flex-col">
      <h3 class="text-2xl font-bold text-gray-900 mb-3 group-hover:text-primary transition-colors duration-300">
        {{ name }}
      </h3>
      <p v-if="description" class="text-gray-600 mb-6 flex-1 leading-relaxed">
        {{ description }}
      </p>

      <!-- Location Count -->
      <div v-if="locationCount !== undefined" class="flex items-center gap-2 text-sm text-primary font-semibold mb-6">
        <span class="inline-block w-2 h-2 rounded-full bg-primary"></span>
        {{ locationCount }} {{ locationCount === 1 ? 'lokasi' : 'lokasi' }} tersedia
      </div>

      <!-- Button -->
      <div class="inline-block w-full text-center bg-gradient-to-r from-primary to-blue-500 text-white px-6 py-4 rounded-xl font-bold group-hover:from-primary-light group-hover:to-blue-600 transition-all duration-300 shadow-button group-hover:shadow-lg transform group-hover:scale-105">
        ➜ Lihat Lokasi
      </div>
    </div>
  </RouterLink>
</template>

<script setup>
defineProps({
  name: {
    type: String,
    required: true
  },
  description: {
    type: String,
    default: ''
  },
  icon: {
    type: String,
    required: true
  },
  to: {
    type: String,
    required: true
  },
  locationCount: {
    type: Number,
    default: undefined
  }
});
</script>
