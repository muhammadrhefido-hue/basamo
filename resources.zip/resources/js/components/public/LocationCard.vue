<template>
  <RouterLink
    :to="to"
    class="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden flex flex-col h-full cursor-pointer transform hover:-translate-y-2"
  >
    <!-- Image Section -->
    <div v-if="location.images?.length" class="relative bg-gray-200 overflow-hidden aspect-video">
      <img
        :src="location.images[0].image_url"
        :alt="location.name"
        class="w-full h-full object-contain group-hover:scale-110 transition-transform duration-300"
      >
      <!-- Overlay gradient -->
      <div class="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
      <!-- Badge -->
      <div v-if="location.is_published" class="absolute top-3 right-3 bg-white/95 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-primary">
        ✓ Terverifikasi
      </div>
    </div>
    <div v-else class="relative h-48 bg-gradient-to-br from-primary/20 via-blue-100 to-primary/10 flex items-center justify-center text-6xl">
      {{ icon }}
    </div>

    <!-- Content Section -->
    <div class="p-6 flex-1 flex flex-col">
      <h3 class="font-bold text-lg md:text-xl text-gray-900 mb-2 group-hover:text-primary transition-colors line-clamp-2">
        {{ location.name }}
      </h3>

      <p class="text-sm text-gray-600 mb-4 flex-1 line-clamp-3 leading-relaxed">
        {{ location.description }}
      </p>

      <!-- Accessibility Info Preview -->
      <div v-if="location.accessibility_info" class="mb-4 text-xs text-green-700 bg-green-50 p-3 rounded-lg border border-green-200">
        <span class="font-bold block mb-1">♿ Aksesibilitas:</span>
        <p class="line-clamp-2">{{ truncateText(location.accessibility_info, 60) }}...</p>
      </div>

      <!-- Footer with arrow -->
      <div class="flex items-center justify-between pt-4 border-t border-gray-100">
        <span class="text-xs font-semibold text-primary">Lihat Detail</span>
        <span class="text-lg group-hover:translate-x-2 transition-transform duration-300">→</span>
      </div>
    </div>
  </RouterLink>
</template>

<script setup>
defineProps({
  location: {
    type: Object,
    required: true,
    validator: (obj) => obj.name && obj.description
  },
  to: {
    type: String,
    required: true
  },
  icon: {
    type: String,
    default: '📍'
  }
});

const truncateText = (text, length) => {
  if (!text) return '';
  return text.substring(0, length).split('\n')[0];
};
</script>
