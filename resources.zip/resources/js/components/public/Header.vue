<template>
  <header class="sticky top-0 z-40 bg-primary shadow-md">
    <nav class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
      <!-- Logo -->
      <RouterLink to="/" class="flex items-center gap-2 group">
        <img src="/logo.png" alt="BASAMO Logo" class="h-10 w-auto group-hover:scale-110 transition-transform">
        <span class="font-bold text-white text-xl hidden sm:inline">BASAMO</span>
      </RouterLink>

      <!-- Desktop Menu -->
      <div class="hidden md:flex items-center gap-8">
        <RouterLink
          to="/"
          class="text-white hover:text-blue-200 transition-colors font-medium"
          :class="{ 'text-blue-100 border-b-2 border-white': $route.name === 'home' }"
        >
          Beranda
        </RouterLink>
        <RouterLink
          to="/lokasi"
          class="text-white hover:text-blue-200 transition-colors font-medium"
          :class="{ 'text-blue-100 border-b-2 border-white': ['categories', 'categoryLocations', 'locationDetail'].includes($route.name) }"
        >
          Lokasi
        </RouterLink>
        <RouterLink
          to="/tentang"
          class="text-white hover:text-blue-200 transition-colors font-medium"
          :class="{ 'text-blue-100 border-b-2 border-white': $route.name === 'about' }"
        >
          Tentang
        </RouterLink>
      </div>

      <!-- Mobile Menu Button -->
      <button
        @click="isMenuOpen = !isMenuOpen"
        class="md:hidden text-white p-2"
      >
        <svg v-if="!isMenuOpen" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
        </svg>
        <svg v-else class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>
    </nav>

    <!-- Mobile Menu -->
    <div v-if="isMenuOpen" class="md:hidden bg-primary-dark">
      <div class="px-6 py-4 space-y-2 max-w-7xl mx-auto">
        <RouterLink
          to="/"
          @click="isMenuOpen = false"
          class="block text-white hover:text-blue-200 py-2 font-medium"
        >
          Beranda
        </RouterLink>
        <RouterLink
          to="/lokasi"
          @click="isMenuOpen = false"
          class="block text-white hover:text-blue-200 py-2 font-medium"
        >
          Lokasi
        </RouterLink>
        <RouterLink
          to="/tentang"
          @click="isMenuOpen = false"
          class="block text-white hover:text-blue-200 py-2 font-medium"
        >
          Tentang
        </RouterLink>
      </div>
    </div>
  </header>
</template>

<script setup>
import { ref } from 'vue';
import { useRoute } from 'vue-router';

const isMenuOpen = ref(false);
const route = useRoute();
</script>
