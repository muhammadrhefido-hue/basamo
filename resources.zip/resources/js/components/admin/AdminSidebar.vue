<template>
  <aside class="w-64 bg-primary-dark min-h-screen p-6">
    <nav class="space-y-2">
      <RouterLink
        to="/admin"
        class="block px-4 py-3 rounded-lg text-white hover:bg-primary transition-colors font-medium"
        :class="{ 'bg-primary': $route.name === 'adminDashboard' }"
      >
        Dashboard
      </RouterLink>
      <RouterLink
        to="/admin/lokasi"
        class="block px-4 py-3 rounded-lg text-white hover:bg-primary transition-colors font-medium"
        :class="{ 'bg-primary': ['adminLocations', 'adminLocationCreate', 'adminLocationEdit'].includes($route.name) }"
      >
        Kelola Lokasi
      </RouterLink>
      <RouterLink
        to="/admin/kategori"
        class="block px-4 py-3 rounded-lg text-white hover:bg-primary transition-colors font-medium"
        :class="{ 'bg-primary': ['adminCategories', 'adminCategoryCreate', 'adminCategoryEdit'].includes($route.name) }"
      >
        Kelola Kategori
      </RouterLink>
    </nav>
  </aside>
</template>

<script setup>
import { RouterLink } from 'vue-router';
</script>
