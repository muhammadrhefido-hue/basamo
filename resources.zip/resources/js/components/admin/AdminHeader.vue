<template>
  <header class="bg-primary shadow-md">
    <div class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
      <!-- Logo -->
      <RouterLink to="/admin" class="flex items-center gap-2 group">
        <img src="/logo.png" alt="BASAMO Logo" class="h-10 w-auto group-hover:scale-110 transition-transform">
        <span class="font-bold text-white text-lg">Admin</span>
      </RouterLink>

      <!-- Logout Button -->
      <button
        @click="handleLogout"
        class="bg-white text-primary px-4 py-2 rounded-lg font-medium hover:bg-blue-50 transition-colors"
      >
        Keluar
      </button>
    </div>
  </header>
</template>

<script setup>
import { useRouter } from 'vue-router';
import { useAuthStore } from '../../stores/authStore';

const router = useRouter();
const authStore = useAuthStore();

const handleLogout = async () => {
  if (confirm('Apakah Anda yakin ingin keluar?')) {
    await authStore.logout();
    router.push({ name: 'adminLogin' });
  }
};
</script>
