<?php

// use Illuminate\Http\Request;
// use Illuminate\Support\Facades\Route;

// Route::get('/user', function (Request $request) {
//     return $request->user();
// })->middleware('auth:sanctum');

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\LocationController;
use App\Http\Controllers\Api\Admin\AuthController;
use App\Http\Controllers\Api\Admin\LocationController as AdminLocationController;
use App\Http\Controllers\Api\Admin\LocationImageController;
use App\Http\Controllers\Api\Admin\CategoryController as AdminCategoryController;
use App\Http\Controllers\ChatController;

/*
|--------------------------------------------------------------------------
| BASAMO Public API
|--------------------------------------------------------------------------
*/

Route::prefix('categories')->group(function () {

    // Semua kategori
    Route::get('/', [CategoryController::class, 'index']);

    // Detail kategori + daftar lokasi
    Route::get('/{slug}', [CategoryController::class, 'show']);

});

Route::prefix('locations')->group(function () {

    // Detail lokasi
    Route::get('/{slug}', [LocationController::class, 'show']);
});

/*
|--------------------------------------------------------------------------
| Chat API
|--------------------------------------------------------------------------
*/
Route::post('/chat', [ChatController::class, 'chat']);

Route::prefix('admin')->group(function () {

    Route::post('/login', [AuthController::class, 'login']);

    Route::middleware('auth:sanctum')->group(function () {
        // Categories
        Route::get('/categories', [AdminCategoryController::class, 'index']);
        Route::get('/categories/{id}', [AdminCategoryController::class, 'show']);
        Route::post('/categories', [AdminCategoryController::class, 'store']);
        Route::put('/categories/{id}', [AdminCategoryController::class, 'update']);
        Route::delete('/categories/{id}', [AdminCategoryController::class, 'destroy']);

        Route::post('/locations', [AdminLocationController::class, 'store']);
        Route::get('/locations', [AdminLocationController::class, 'index']);
        Route::get('/locations/{id}', [AdminLocationController::class, 'show']);
        Route::put('/locations/{id}', [AdminLocationController::class, 'update']);
        Route::delete('/locations/{id}', [AdminLocationController::class, 'destroy']);
        Route::post('/logout', [AuthController::class, 'logout']);

        // Location Image Routes
        Route::get('/locations/{locationId}/images', [LocationImageController::class, 'index']);
        Route::post('/locations/{locationId}/images', [LocationImageController::class, 'store']);
        Route::put('/locations/images/{id}', [LocationImageController::class, 'update']);
        Route::delete('/locations/images/{id}', [LocationImageController::class, 'destroy']);

        // Location Publish Route
        Route::patch(
            '/locations/{id}/publish',
            [AdminLocationController::class, 'publish']
        );
    });

});
