<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->bind('path.public', function () {
            // Check if there is an environment override and it exists
            $customPublic = env('PUBLIC_PATH');
            if ($customPublic && is_dir($customPublic)) {
                return rtrim($customPublic, '/\\');
            }

            // Auto-detect sibling public_html (common in cPanel hosting)
            $siblingPublicHtml = realpath(base_path('../public_html'));
            if ($siblingPublicHtml && is_dir($siblingPublicHtml)) {
                return $siblingPublicHtml;
            }

            if (is_dir(base_path('../public_html'))) {
                return base_path('../public_html');
            }

            return base_path('public');
        });
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
    }
}
