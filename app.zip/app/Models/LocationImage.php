<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LocationImage extends Model
{
    protected $fillable = [
        'location_id',
        'image_path'
    ];

    protected $appends = ['image_url'];

    public function getImageUrlAttribute()
    {
        $baseUrl = app()->runningInConsole() ? config('app.url') : request()->getSchemeAndHttpHost();
        return rtrim($baseUrl, '/') . '/storage/' . $this->image_path;
    }

    public function location()
    {
        return $this->belongsTo(Location::class);
    }
}
