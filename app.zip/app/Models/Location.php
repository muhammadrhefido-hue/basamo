<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Location extends Model
{
    protected $fillable = [
        'category_id',
        'name',
        'slug',
        'description',
        'accessibility_info',
        'notes',
        'google_maps_url',
        'is_published'
    ];

        public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function images()
    {
        return $this->hasMany(LocationImage::class);
    }
}
