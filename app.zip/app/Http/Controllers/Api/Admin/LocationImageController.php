<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Location;
use App\Models\LocationImage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class LocationImageController extends Controller
{
    public function index(int $locationId)
    {
        $location = Location::with('images')->find($locationId);

        if (!$location) {
            return response()->json([
                'success' => false,
                'message' => 'Lokasi tidak ditemukan.'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $location->images
        ]);
    }

    public function store(Request $request, int $locationId)
    {
        $location = Location::find($locationId);

        if (!$location) {
            return response()->json([
                'success' => false,
                'message' => 'Lokasi tidak ditemukan.'
            ], 404);
        }

        $request->validate([
            'image' => ['required', 'file', 'mimes:jpg,jpeg,png,webp,gif,svg,bmp,JPG,JPEG,PNG,WEBP', 'max:20480'],
        ]);

        try {
            $file = $request->file('image');
            $extension = strtolower($file->getClientOriginalExtension() ?: 'jpg');
            $filename = uniqid('loc_', true) . '_' . time() . '.' . $extension;
            
            $storageAppPath = storage_path('app/public/locations');
            if (!is_dir($storageAppPath)) {
                @mkdir($storageAppPath, 0777, true);
            }

            $publicPath = app('path.public');
            $publicLocationsPath = rtrim($publicPath, '/\\') . '/storage/locations';
            if (!is_dir($publicLocationsPath)) {
                @mkdir($publicLocationsPath, 0777, true);
            }

            // Move to storage_path first (always within Laravel workspace)
            $file->move($storageAppPath, $filename);
            @chmod($storageAppPath . '/' . $filename, 0644);

            // Copy to public_html/storage/locations if it's a separate physical directory
            if (is_dir($publicLocationsPath) && realpath($publicLocationsPath) !== realpath($storageAppPath)) {
                @copy($storageAppPath . '/' . $filename, $publicLocationsPath . '/' . $filename);
                @chmod($publicLocationsPath . '/' . $filename, 0644);
            }

            $imagePath = 'locations/' . $filename;

            $image = LocationImage::create([
                'location_id' => $location->id,
                'image_path' => $imagePath,
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Foto berhasil diupload.',
                'data' => $image,
            ], 201);
        } catch (\Throwable $e) {
            \Log::error('Image upload error: ' . $e->getMessage(), ['file' => $e->getFile(), 'line' => $e->getLine()]);
            return response()->json([
                'success' => false,
                'message' => 'Gagal mengupload foto: ' . $e->getMessage()
            ], 500);
        }
    }

    public function update(Request $request, int $id)
    {
        $image = LocationImage::find($id);

        if (!$image) {
            return response()->json([
                'success' => false,
                'message' => 'Foto tidak ditemukan.'
            ], 404);
        }

        $request->validate([
            'image' => ['required', 'file', 'mimes:jpg,jpeg,png,webp,gif,svg,bmp,JPG,JPEG,PNG,WEBP', 'max:20480'],
        ]);

        try {
            $publicPath = app('path.public');
            $publicLocationsPath = rtrim($publicPath, '/\\') . '/storage/locations';
            $storageAppPath = storage_path('app/public/locations');

            // Delete old file
            @unlink($publicLocationsPath . '/' . basename($image->image_path));
            @unlink($storageAppPath . '/' . basename($image->image_path));

            // Save new file
            $file = $request->file('image');
            $extension = strtolower($file->getClientOriginalExtension() ?: 'jpg');
            $filename = uniqid('loc_', true) . '_' . time() . '.' . $extension;

            if (!is_dir($publicLocationsPath)) {
                @mkdir($publicLocationsPath, 0777, true);
            }
            if (!is_dir($storageAppPath)) {
                @mkdir($storageAppPath, 0777, true);
            }

            $targetFile = $publicLocationsPath . '/' . $filename;
            $file->move($publicLocationsPath, $filename);
            @chmod($targetFile, 0644);

            $backupFile = $storageAppPath . '/' . $filename;
            if (realpath($publicLocationsPath) !== realpath($storageAppPath) && file_exists($targetFile)) {
                @copy($targetFile, $backupFile);
                @chmod($backupFile, 0644);
            }

            $imagePath = 'locations/' . $filename;

            $image->update([
                'image_path' => $imagePath,
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Foto berhasil diperbarui.',
                'data' => $image->fresh(),
            ]);
        } catch (\Throwable $e) {
            \Log::error('Image update error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Gagal memperbarui foto: ' . $e->getMessage()
            ], 500);
        }
    }

    public function destroy(int $id)
    {
        $image = LocationImage::find($id);

        if (!$image) {
            return response()->json([
                'success' => false,
                'message' => 'Foto tidak ditemukan.'
            ], 404);
        }

        try {
            $publicPath = app('path.public');
            $publicLocationsPath = rtrim($publicPath, '/\\') . '/storage/locations';
            $storageAppPath = storage_path('app/public/locations');

            @unlink($publicLocationsPath . '/' . basename($image->image_path));
            @unlink($storageAppPath . '/' . basename($image->image_path));

            $image->delete();

            return response()->json([
                'success' => true,
                'message' => 'Foto berhasil dihapus.'
            ]);
        } catch (\Throwable $e) {
            \Log::error('Image delete error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Gagal menghapus foto.'
            ], 500);
        }
    }
}

