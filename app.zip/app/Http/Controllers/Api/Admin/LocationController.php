<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Location;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class LocationController extends Controller
{
    public function index()
    {
        $locations = Location::with('category')
            ->latest()
            ->get();

        return response()->json([
            'success' => true,
            'data' => $locations,
        ]);
    }

    public function show(int $id)
    {
        $location = Location::with([
            'category',
            'images'
        ])->find($id);

        if (!$location) {
            return response()->json([
                'success' => false,
                'message' => 'Lokasi tidak ditemukan.',
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $location,
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'category_id' => ['required', 'exists:categories,id'],
            'name' => ['required', 'max:255'],
            'description' => ['required'],
            'accessibility_info' => ['required'],
            'notes' => ['nullable'],
            'google_maps_url' => ['required', 'url'],
            'is_published' => ['nullable', 'boolean'],
        ]);

        $isPublished = $request->boolean('is_published', false);

        $location = Location::create([
            'category_id' => $validated['category_id'],
            'name' => $validated['name'],
            'slug' => Str::slug($validated['name']),
            'description' => $validated['description'],
            'accessibility_info' => $validated['accessibility_info'],
            'notes' => $validated['notes'] ?? null,
            'google_maps_url' => $validated['google_maps_url'],
            'is_published' => $isPublished,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Lokasi berhasil ditambahkan.',
            'data' => $location,
        ], 201);
    }

    public function update(Request $request, int $id)
    {
        $location = Location::find($id);

        if (!$location) {
            return response()->json([
                'success' => false,
                'message' => 'Lokasi tidak ditemukan.',
            ], 404);
        }

        $validated = $request->validate([
            'category_id' => ['required', 'exists:categories,id'],
            'name' => ['required', 'max:255'],
            'description' => ['required'],
            'accessibility_info' => ['required'],
            'notes' => ['nullable'],
            'google_maps_url' => ['required', 'url'],
            'is_published' => ['nullable', 'boolean'],
        ]);

        $isPublished = $request->has('is_published') 
            ? $request->boolean('is_published') 
            : $location->is_published;

        $location->update([
            'category_id' => $validated['category_id'],
            'name' => $validated['name'],
            'slug' => Str::slug($validated['name']),
            'description' => $validated['description'],
            'accessibility_info' => $validated['accessibility_info'],
            'notes' => $validated['notes'] ?? null,
            'google_maps_url' => $validated['google_maps_url'],
            'is_published' => $isPublished,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Lokasi berhasil diperbarui.',
            'data' => $location->fresh(),
        ]);
    }

    public function destroy(int $id)
    {
        $location = Location::find($id);

        if (!$location) {
            return response()->json([
                'success' => false,
                'message' => 'Lokasi tidak ditemukan.',
            ], 404);
        }

        $location->delete();

        return response()->json([
            'success' => true,
            'message' => 'Lokasi berhasil dihapus.',
        ]);
    }

    public function publish(int $id)
    {
        $location = Location::with('images')->find($id);

        if (!$location) {
            return response()->json([
                'success' => false,
                'message' => 'Lokasi tidak ditemukan.'
            ], 404);
        }

        // Toggle published state or set to true
        $newStatus = !$location->is_published;

        $location->update([
            'is_published' => $newStatus
        ]);

        $statusText = $newStatus ? 'dipublikasikan' : 'dijadikan draft';

        return response()->json([
            'success' => true,
            'message' => "Lokasi berhasil {$statusText}.",
            'data' => $location->fresh()
        ]);
    }
}
