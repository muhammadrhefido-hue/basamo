<?php

namespace App\Http\Controllers;

use App\Models\Location;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class ChatController extends Controller
{
    /**
     * Handle chat messages and integrate with Grok API
     */
    public function chat(Request $request)
    {
        try {
            $userMessage = $request->input('message');

            if (!$userMessage) {
                return response()->json(['error' => 'Message required'], 400);
            }

            // Get ALL published locations data
            $locationsData = $this->getAllLocationsData();

            // Prepare system prompt with STRICT instruction to only use BASAMO data
            $systemPrompt = $this->buildStrictSystemPrompt($locationsData);

            // Call Groq API
            $response = $this->callGroqAPI($userMessage, $systemPrompt);

            return response()->json([
                'response' => $response
            ]);

        } catch (\Exception $e) {
            $errMsg = $e->getMessage();
            \Log::error('Chat error: ' . $errMsg);
            return response()->json([
                'error' => 'Terjadi kesalahan: ' . $errMsg
            ], 500);
        }
    }

    /**
     * Get ALL published locations data with detailed information
     */
    private function getAllLocationsData(): array
    {
        $locations = Location::where('is_published', true)
            ->with(['category', 'images'])
            ->get();

        $categorizedLocations = [];
        $locationsByCategory = [];

        // Organize by category
        foreach ($locations as $location) {
            $categoryName = $location->category->name;

            if (!isset($locationsByCategory[$categoryName])) {
                $locationsByCategory[$categoryName] = [];
            }

            $locationData = [
                'name' => $location->name,
                'address' => $location->address,
                'phone' => $location->phone,
                'description' => $location->description,
                'category' => $categoryName,
            ];

            $locationsByCategory[$categoryName][] = $locationData;
        }

        return [
            'byCategory' => $locationsByCategory,
            'total' => $locations->count(),
            'categories' => array_keys($locationsByCategory)
        ];
    }

    /**
     * Build STRICT system prompt that ONLY allows answers from BASAMO data
     */
    private function buildStrictSystemPrompt($locationsData): string
    {
        $locationsList = json_encode($locationsData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

        $prompt = <<<PROMPT
Anda adalah BASAMO Chat Bot - Asisten Direktori Lokasi Ramah Disabilitas di Kota Palembang.

⚠️ PERATURAN KETAT:
==================
1. HANYA jawab pertanyaan berdasarkan data lokasi di bawah ini
2. JANGAN membuat informasi lokasi yang tidak ada di database BASAMO
3. JANGAN menambah atau mengubah data lokasi
4. Jika pertanyaan tentang lokasi yang tidak ada = JAWAB "Maaf, informasi lokasi tersebut tidak tersedia di database BASAMO"
5. Fokus HANYA pada aksesibilitas dan kenyamanan untuk penyandang disabilitas

DATABASE LOKASI BASAMO (SATU-SATUNYA SUMBER DATA YANG VALID):
==============================================================

$locationsList

PETUNJUK JAWABAN:
=================
- Jawab dalam Bahasa Indonesia yang ramah dan profesional
- Jika user tanya kategori tertentu, referensikan data di atas saja
- Jika user tanya daerah tertentu, cek address lokasi di database
- Untuk pertanyaan umum tentang BASAMO, boleh jawab sesuai pengetahuan
- Untuk pertanyaan tentang LOKASI SPESIFIK, HARUS dari database di atas
- Jika tidak ada di database, JANGAN buat jawaban = TOLAK dengan halus

CONTOH JAWABAN YANG BENAR:
===========================
User: "Ada masjid ramah disabilitas di Sako?"
Bot: "Ya, kami memiliki [nama masjid] di [alamat lengkap]. Berikut detailnya: [deskripsi]"

User: "Ada rumah makan di Ilir Barat?"
Bot: "Maaf, informasi lokasi rumah makan di Ilir Barat tidak tersedia di database BASAMO. Silakan cek halaman Lokasi kami untuk melihat semua tempat yang tersedia."

CONTOH JAWABAN YANG SALAH:
============================
❌ Bot membuat data lokasi yang tidak ada di database
❌ Bot jawab "Menurut saya, seharusnya ada..."
❌ Bot memberikan rekomendasi umum tanpa data BASAMO

INGAT: Kredibilitas BASAMO tergantung pada akurasi data! 🚀
PROMPT;

        return $prompt;
    }

    /**
     * Call Groq API with strict data constraints (100% FREE, UNLIMITED!)
     */
    private function callGroqAPI($userMessage, $systemPrompt): string
    {
        $apiKey = config('services.groq.key');
        $endpoint = config('services.groq.endpoint', 'https://api.groq.com/openai/v1/chat/completions');

        \Log::info('Groq Chat API Debug', [
            'has_api_key' => !empty($apiKey),
            'api_key_length' => strlen($apiKey ?? ''),
            'endpoint' => $endpoint
        ]);

        if (!$apiKey) {
            throw new \Exception('Groq API key not configured. Add GROQ_API_KEY to .env');
        }

        try {
            // Groq models available for this API key tier
            $payload = [
                'model' => 'qwen/qwen3.8-27b',
                'messages' => [
                    [
                        'role' => 'system',
                        'content' => $systemPrompt
                    ],
                    [
                        'role' => 'user',
                        'content' => $userMessage
                    ]
                ],
                'temperature' => 0.5,
                'max_tokens' => 1000
            ];

            \Log::info('Calling Groq API', [
                'model' => $payload['model'],
                'messages_count' => count($payload['messages']),
                'endpoint' => $endpoint
            ]);

            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $apiKey,
                'Content-Type' => 'application/json'
            ])->withOptions([
                'verify' => false,  // needed for some shared hosting environments
            ])->timeout(30)->post($endpoint, $payload);

            \Log::info('Groq API Response', [
                'status' => $response->status(),
                'has_error' => $response->failed()
            ]);

            if ($response->failed()) {
                $errorBody = $response->body();
                \Log::error('Groq API error response: ' . $errorBody);
                throw new \Exception('Groq API request failed: ' . $response->status() . ' - ' . $errorBody);
            }

            $data = $response->json();
            $content = $data['choices'][0]['message']['content'] ?? null;

            if (!$content) {
                \Log::error('No content in Groq response', ['data' => $data]);
                throw new \Exception('No content in Groq response');
            }

            return $content;

        } catch (\Exception $e) {
            \Log::error('Groq API call error: ' . $e->getMessage());
            throw $e;
        }
    }
}
